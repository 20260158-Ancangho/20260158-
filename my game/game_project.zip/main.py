#main.py

import pygame

from settings import *
from ui import (
    draw_select_screen,
    is_commander_card_clicked,
    draw_stage_screen,
    is_stage_start_clicked,
    draw_card_reward_screen,
    draw_augment_reward_screen,
    get_reward_clicked
)
from game_manager import Game


pygame.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("WW2 RTS Prototype - Card System")

clock = pygame.time.Clock()

font = pygame.font.SysFont("malgungothic", 18)
big_font = pygame.font.SysFont("malgungothic", 42)

game_state = STATE_SELECT
game = None
current_stage = 1
augment_pick_count = 0

running = True

while running:
    clock.tick(FPS)

    # -----------------------------
    # 이벤트 처리
    # -----------------------------

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        # -----------------------------
        # 지휘관 선택
        # -----------------------------

        if game_state == STATE_SELECT:

            if event.type == pygame.MOUSEBUTTONDOWN:

                mx, my = pygame.mouse.get_pos()

                if is_commander_card_clicked(mx, my):

                    game = Game(current_stage)
                    game_state = STATE_STAGE
        
        #스테이지 시작 
        elif game_state == STATE_STAGE:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                if is_stage_start_clicked(mx, my):
                    game = Game(current_stage)
                    game_state = STATE_GAME
                    
        elif game_state == STATE_CARD_REWARD:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                reward = get_reward_clicked(mx, my)

                if reward is not None:
                    augment_pick_count = 0
                    game_state = STATE_AUGMENT_REWARD

        elif game_state == STATE_AUGMENT_REWARD:

            if event.type == pygame.MOUSEBUTTONDOWN:

                mx, my = pygame.mouse.get_pos()

                reward = get_reward_clicked(mx, my)

                if reward is not None:

                    augment_pick_count += 1

                    # 증강 2번 선택
                    if augment_pick_count < 2:
                        pass

                    else:
                        current_stage += 1

                        if current_stage > MAX_STAGE:
                            current_stage = 1
                            game_state = STATE_SELECT

                        else:
                            game = Game(current_stage)
                            game_state = STATE_STAGE

        # -----------------------------
        # 실제 게임
        # -----------------------------

        elif game_state == STATE_GAME:

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_1:
                    if game.selected_skill == "bombardment":
                        game.selected_skill = None
                    else:
                        game.selected_skill = "bombardment"
                    game.selected_card = None

                elif event.key == pygame.K_2:
                    if game.selected_skill == "navy" and game is not None:
                        game.selected_skill = None
                    else:
                        game.selected_skill = "navy"
                    game.selected_card = None

                elif event.key == pygame.K_q:
                    game.selected_card = None if game.selected_card == 0 else 0
                    game.selected_skill = None

                elif event.key == pygame.K_w:
                    game.selected_card = None if game.selected_card == 1 else 1
                    game.selected_skill = None

                elif event.key == pygame.K_e:
                    game.selected_card = None if game.selected_card == 2 else 2
                    game.selected_skill = None

                elif event.key == pygame.K_r:
                    game.selected_card = None if game.selected_card == 3 else 3
                    game.selected_skill = None

                elif event.key == pygame.K_ESCAPE:
                    game.selected_card = None
                    game.selected_skill = None

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    mx, my = pygame.mouse.get_pos()
                    game.place_selected(mx, my)
                    
            #카드 보상 처리
            elif game_state == STATE_CARD_REWARD:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()

                    reward = get_reward_clicked(mx, my)

                    if reward is not None:
                        game_state = STATE_AUGMENT_REWARD
                       
                       
            elif game_state == STATE_AUGMENT_REWARD:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()

                    reward = get_reward_clicked(mx, my)

                    if reward is not None:
                        current_stage += 1

                        if current_stage > MAX_STAGE:
                            current_stage = 1
                            game_state = STATE_SELECT
                        else:
                            game = Game(current_stage)
                            game_state = STATE_STAGE

    # -----------------------------
    # 화면 그리기
    # -----------------------------

    screen.fill((20, 20, 20))

    if game_state == STATE_SELECT:
        draw_select_screen(screen, font, big_font)

    elif game_state == STATE_STAGE:
        draw_stage_screen(screen, font, big_font, current_stage)

    elif game_state == STATE_GAME:
        game.update()

        if game.is_stage_cleared():
            game_state = STATE_CARD_REWARD

        game.draw(screen, font)

    elif game_state == STATE_CARD_REWARD:
        draw_card_reward_screen(screen, font, big_font)

    elif game_state == STATE_AUGMENT_REWARD:
        draw_augment_reward_screen(
            screen,
            font,
            big_font,
            augment_pick_count
        )

    pygame.display.flip()

pygame.quit()