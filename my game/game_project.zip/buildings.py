# buildings.py

import pygame
import math

from settings import *
from utils import draw_text
from effects import FloatingText


class Building:
    def __init__(self, x, y, side, name, hp, is_main=False):
        self.rect = pygame.Rect(x, y, 90, 70)
        self.side = side
        self.name = name
        self.max_hp = hp
        self.hp = hp
        self.is_main = is_main
        self.unit_type = TYPE_BUILDING
        
        self.unit_type = TYPE_BUILDING
        self.is_main = is_main
        self.last_attack = 0
        
        if hp is not None:
            self.hp = hp
            self.max_hp = hp

        if self.is_main:
            self.max_hp = 7325
            self.hp = 7325
            self.damage = {
                TYPE_INFANTRY: 439,
                TYPE_VEHICLE: 621,
                TYPE_TANK: 810,
                TYPE_BUILDING: 460,
            }
            self.attack_delay = 2000
            self.attack_range = 140
            self.splash_radius = 45
        else:
            self.max_hp = 5125
            self.hp = 5125
            self.damage = {
                TYPE_INFANTRY: 32,
                TYPE_VEHICLE: 45,
                TYPE_TANK: 50,
                TYPE_BUILDING: 40,
            }
            self.attack_delay = 200
            self.attack_range = 130
            self.splash_radius = 0

    def draw(self, screen, font):
        color = BLUE if self.side == PLAYER else RED

        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, BLACK, self.rect, 2)

        hp_ratio = self.hp / self.max_hp
        pygame.draw.rect(screen, RED, (self.rect.x, self.rect.y - 10, self.rect.w, 6))
        pygame.draw.rect(screen, GREEN, (self.rect.x, self.rect.y - 10, self.rect.w * hp_ratio, 6))

        label = "주 건물" if self.is_main else "보조"
        draw_text(screen, font, label, self.rect.x + 10, self.rect.y + 22, WHITE)

    def take_damage(self, amount, floating_texts):
        self.hp -= amount
        floating_texts.append(
            FloatingText(f"-{int(amount)}", self.rect.centerx, self.rect.y, YELLOW)
        )

        if self.hp <= 0:
            self.hp = 0
            
    def update(self, now, units, buildings, floating_texts):
        if self.hp <= 0:
            return

        target = self.find_target(units, buildings)

        if target is None:
            return

        if now - self.last_attack < self.attack_delay:
            return

        self.last_attack = now

        target_type = getattr(target, "unit_type", TYPE_BUILDING)
        damage = self.damage.get(target_type, 0)

        if damage <= 0:
            return

        if self.splash_radius > 0:
            self.area_damage(target, damage, units, buildings, floating_texts)
        else:
            target.take_damage(damage, floating_texts)


    def find_target(self, units, buildings):
        targets = []

        for unit in units:
            if unit.side != self.side and unit.hp > 0:
                if self.distance_to(unit) <= self.attack_range:
                    targets.append(unit)

        for building in buildings:
            if building.side != self.side and building.hp > 0:
                if self.distance_to(building) <= self.attack_range:
                    targets.append(building)

        if not targets:
            return None

        targets.sort(key=lambda t: self.distance_to(t))
        return targets[0]


    def area_damage(self, target, damage, units, buildings, floating_texts):
        tx = target.rect.centerx
        ty = target.rect.centery

        for unit in units:
            if unit.side != self.side and unit.hp > 0:
                if self.distance_to_point(unit, tx, ty) <= self.splash_radius:
                    unit_type = getattr(unit, "unit_type", TYPE_INFANTRY)
                    final_damage = self.damage.get(unit_type, damage)
                    unit.take_damage(final_damage, floating_texts)

        for building in buildings:
            if building.side != self.side and building.hp > 0:
                if self.distance_to_point(building, tx, ty) <= self.splash_radius:
                    final_damage = self.damage.get(TYPE_BUILDING, damage)
                    building.take_damage(final_damage, floating_texts)


    def distance_to(self, target):
        return math.hypot(
            self.rect.centerx - target.rect.centerx,
            self.rect.centery - target.rect.centery
        )


    def distance_to_point(self, target, x, y):
        return math.hypot(
            target.rect.centerx - x,
            target.rect.centery - y
        )


def create_default_buildings():
    buildings = []

    buildings.append(Building(*PLAYER_LEFT_TOWER_POS, PLAYER, "Player Left Tower", 3500))
    buildings.append(Building(*PLAYER_RIGHT_TOWER_POS, PLAYER, "Player Right Tower", 3500))
    buildings.append(Building(*PLAYER_HQ_POS, PLAYER, "Player HQ", 6000, is_main=True))

    buildings.append(Building(*ENEMY_LEFT_TOWER_POS, ENEMY, "Enemy Left Tower", 3500))
    buildings.append(Building(*ENEMY_RIGHT_TOWER_POS, ENEMY, "Enemy Right Tower", 3500))
    buildings.append(Building(*ENEMY_HQ_POS, ENEMY, "Enemy HQ", 6000, is_main=True))

    return buildings