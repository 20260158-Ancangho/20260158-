# game.py

import random
import pygame
import json

from settings import *
from cards import CARD_POOL, STAGE1_ENEMY_CARDS, get_card_by_id, STAGE2_ENEMY_CARDS
from buildings import create_default_buildings
from units import create_units_from_card
from commanders import YamamotoCommander, NAVY_SQUAD
from ui import draw_battlefield, draw_game_ui, draw_placement_preview
from augments import AUGMENTS
from effects import MuzzleFlash


class Game:
    def __init__(self, stage=1):
        self.stage = stage
        self.units = []
        self.buildings = create_default_buildings()
        self.shells = []
        self.floating_texts = []
        
        self.left_lane_owner = PLAYER
        self.right_lane_owner = PLAYER

        self.commander = YamamotoCommander()

        # 일반 카드 코스트
        self.cost = START_COST
        self.max_cost = MAX_COST
        self.last_cost_time = 0
        self.start_time = pygame.time.get_ticks()

        # 지휘 스킬용 지휘력
        self.command_points = START_COMMAND_POINTS
        self.max_command_points = MAX_COMMAND_POINTS
        self.last_command_time = 0

        # 카드 덱 / 손패 / 다음 카드
        self.draw_pile = CARD_POOL.copy()
        random.shuffle(self.draw_pile)

        self.hand = []
        self.next_card = None
        self.selected_card = None
        self.selected_skill = None

        self.init_hand()
        
        self.last_enemy_spawn = 0
        
        import units
        units.GAME_INSTANCE = self
        
        self.enemy_cost = START_COST
        self.enemy_max_cost = MAX_COST

        self.enemy_last_cost_time = pygame.time.get_ticks()
        
        self.enemy_queued_card = None
        
        self.enemy_ai_last_action = 0
        
        self.last_stage1_event = pygame.time.get_ticks()
        
        self.ability_banner_text = ""
        self.ability_banner_end = 0
        
        # 증강 시스템
        self.augments = []
        self.augment_choices = random.sample(AUGMENTS, 3)
        self.augment_choices = []
        
        self.effects = []
        
        self.enemy_card_penalty = {}
        
        # 증강 시스템
        self.augment_choices = []
        
        self.last_partisan_spawn = pygame.time.get_ticks()
        
        self.waiting_tiger_skill_choice = False
        self.tiger_skill_slot = None
        
    def save_game(self):

        data = {

            "stage": self.stage,

            "cost": self.cost,

            "command_points": self.command_points,
        }

        with open("save.json", "w", encoding="utf-8") as f:
            json.dump(data, f)
            
    def load_game(self):

        with open("save.json", "r", encoding="utf-8") as f:
            data = json.load(f)

        self.stage = data["stage"]

        self.cost = data["cost"]

        self.command_points = data["command_points"]
        
    def is_stage_cleared(self):
        for building in self.buildings:
            if building.side == ENEMY and building.is_main:
                if building.hp <= 0:
                    return True

        return False
    

    def init_hand(self):
        self.hand = []

        for _ in range(4):
            self.hand.append(self.draw_pile.pop(0))

        self.next_card = self.draw_pile[0]

    def update(self):
        now = pygame.time.get_ticks()

        self.recover_cost(now)
        self.recover_command_points(now)

        for unit in self.units:
            unit.update(now, self.units, self.buildings, self.floating_texts, self.effects)
            
        for building in self.buildings:
            building.update(
                now,
                self.units,
                self.buildings,
                self.floating_texts
            )

        for shell in self.shells:
            shell.update(self.units, self.buildings, self.floating_texts)

        for text in self.floating_texts:
            text.update()
            
        self.effects = [e for e in self.effects if e.alive()]
        self.units = [u for u in self.units if u.hp > 0]
        self.shells = [
            s for s in self.shells
            if not (s.exploded and s.timer > s.delay + 20)
        ]
        self.floating_texts = [
            t for t in self.floating_texts
            if t.life > 0
        ]
        
        self.update_side_lane_control()
        
        now = pygame.time.get_ticks()

        enemy_recover = EARLY_COST_RECOVER_TIME

        if now - self.start_time >= COST_ACCEL_TIME:
            enemy_recover = LATE_COST_RECOVER_TIME

        if now - self.enemy_last_cost_time >= enemy_recover:

            if self.enemy_cost < self.enemy_max_cost:
                self.enemy_cost += 1

            self.enemy_last_cost_time = now
            
        self.update_enemy_ai()
        
        if self.stage == 1:
            self.update_stage1_event()
            
        if self.stage == 2:
            self.update_stage2_event()
            
        self.effects = [
            e for e in self.effects
            if e.alive()
        ]
    
    def update_enemy_ai(self):

        now = pygame.time.get_ticks()
        
        if self.stage == 1:
            enemy_pool = STAGE1_ENEMY_CARDS

        elif self.stage == 2:
            enemy_pool = STAGE2_ENEMY_CARDS

        else:
            enemy_pool = STAGE1_ENEMY_CARDS

        if now - self.enemy_ai_last_action < 1800:
            return
        
        if self.enemy_queued_card is None:
            self.enemy_queued_card = self.pick_enemy_card()

        card = self.enemy_queued_card

        if self.enemy_cost < card["cost"]:
            return
        
        for name in list(self.enemy_card_penalty.keys()):
            self.enemy_card_penalty[name] = max(0, self.enemy_card_penalty[name] - 2)

        self.enemy_card_penalty[card["name"]] = 45

        left_count = 0
        right_count = 0

        for unit in self.units:

            if unit.side != PLAYER:
                continue

            if unit.rect.centerx < WIDTH // 2:
                left_count += 1
            else:
                right_count += 1

        if left_count > right_count:
            lane = "left"

        elif right_count > left_count:
            lane = "right"

        else:
            lane = random.choice(["left", "right"])

        if lane == "left":
            spawn_x = 260
        else:
            spawn_x = 720

        spawn_y = 80

        enemy_card = card.copy()
        enemy_card["active_augments"] = self.augments.copy()
        enemy_card["enemy_rear_spawn"] = True

        new_units = create_units_from_card(enemy_card, spawn_x, spawn_y, ENEMY)

        self.units.extend(new_units)

        self.enemy_cost -= card["cost"]
        self.enemy_queued_card = None

        self.enemy_ai_last_action = now
        
    def pick_enemy_card(self):
        if self.stage == 1:
            enemy_pool = STAGE1_ENEMY_CARDS
        elif self.stage == 2:
            enemy_pool = STAGE2_ENEMY_CARDS
        else:
            enemy_pool = STAGE1_ENEMY_CARDS


        weights = []

        for card in enemy_pool:
            name = card["name"]
            penalty = self.enemy_card_penalty.get(name, 0)

            weight = max(0.05, 10 / ((1 + penalty) ** 1.4))
            weights.append(weight)

        return random.choices(
            enemy_pool,
            weights=weights,
            k=1
        )[0]
        
    def update_stage1_event(self):

        now = pygame.time.get_ticks()

        if now - self.last_stage1_event < 66000:
            return

        card = {
            "name": "셔먼 전차",
            "cost": 0,
            "hp": 4650,
            "count": 1,
            "damage": {
                TYPE_INFANTRY: 650,
                TYPE_VEHICLE: 918,
                TYPE_TANK: 1450,
                TYPE_BUILDING: 450,
            },
            "attack_delay": 2500,
            "attack_range": 100,
            "speed": SPEED_NORMAL,
            "unit_type": TYPE_TANK
        }
        
        card["active_augments"] = self.augments
        entry_type = random.choice(["rear", "flank"])
        lane = random.choice(["left", "right"])

        if entry_type == "rear":
            card["enemy_rear_spawn"] = True

            x = 260 if lane == "left" else 720
            y = 80

        else:
            card["enemy_rear_spawn"] = False

            if lane == "left":
                zone = ENEMY_FLANK_ZONES[0]
            else:
                zone = ENEMY_FLANK_ZONES[1]

            x = zone[0] + zone[2] // 2
            y = zone[1] + zone[3] // 2

        units = create_units_from_card(card, x, y, ENEMY)

        self.units.extend(units)
        self.last_stage1_event = now

        self.show_ability_banner("셔먼 전차 증원")
        
    def spawn_partisan(self):
        card = get_card_by_id("partisan").copy()
        card["enemy_rear_spawn"] = False

        # 플레이어가 사용 가능한 측면 구역만 후보로 사용
        available_zones = []

        for zone in PLAYER_FLANK_ZONES:
            rect = pygame.Rect(zone)

            # 네 게임에 side lane 점령 상태 변수가 있다면 여기를 맞춰야 함
            # 예: self.side_lane_owner["left"] == PLAYER
            available_zones.append(rect)

        if available_zones:
            zone = random.choice(available_zones)

            x = zone.centerx
            y = zone.centery

            units = create_units_from_card(card, x, y, ENEMY)
            self.units.extend(units)

        else:
            # 모든 측면 구역을 빼앗긴 경우: 중앙 건물 랜덤 진입로
            card["center_spawn_only"] = True

            entry_points = [
                (405, 260),
                (595, 260),
                (405, 400),
                (595, 400),
            ]

            x, y = random.choice(entry_points)

            units = create_units_from_card(card, x, y, ENEMY)
            self.units.extend(units)
        
    def update_stage2_event(self):
        now = pygame.time.get_ticks()

        if now - self.last_partisan_spawn < 22000:
            return

        self.spawn_partisan()
        self.last_partisan_spawn = now
        
    def show_ability_banner(self, text):

        self.ability_banner_text = text
        self.ability_banner_end = pygame.time.get_ticks() + 2500
        

    def draw(self, screen, font):
        
        big_font = pygame.font.SysFont("malgungothic", 42)

        screen.fill((40, 50, 40))
        
        draw_battlefield(screen, font)
        

        # 건물 그리기
        for building in self.buildings:
            if building.hp > 0:
                building.draw(screen, font)

        # 포격 그리기
        for shell in self.shells:
            shell.draw(screen)

        # -----------------------------
        # 분대 전체 체력 계산
        # 개별 병사가 아니라
        # "분대 총 체력" 기준으로 표시
        # -----------------------------

        squad_totals = {}

        for unit in self.units:
            # -----------------------------
            # 분대 총 체력 계산
            # 개체별 체력은 유지하면서
            # UI만 분대 체력처럼 보이게 함
            # -----------------------------

            if unit.squad_id not in squad_totals:

                squad_totals[unit.squad_id] = [
                    0,
                    unit.card.get(
                        "squad_max_hp",
                        unit.max_hp
                    )
                ]
                

            # 현재 살아있는 유닛 체력 합산
            squad_totals[unit.squad_id][0] += max(0, unit.hp)
        drawn_squads = set()
                

        # 유닛 본체 먼저
        for unit in self.units:
            if unit.hp > 0:
                unit.draw(screen, font, squad_totals, drawn_squads=None)
                
        for effect in self.effects:
            effect.draw(screen)
                
        # 체력바는 가장 나중에
        drawn_squads = set()

        for unit in self.units:
            if unit.hp > 0:
                unit.draw_health_bar(screen, font, squad_totals, drawn_squads)
                
        # -----------------------------
        # 측면 바깥 검은 영역
        # -----------------------------

        # 왼쪽 바깥
        pygame.draw.rect(
            screen,
            (10, 10, 10),
            (0, 0, 150, MAP_BOTTOM)
        )

        # 오른쪽 바깥
        pygame.draw.rect(
            screen,
            (10, 10, 10),
            (880, 0, 150, MAP_BOTTOM)
        )

                

        # 데미지 텍스트
        for text in self.floating_texts:
            text.draw(screen, font)

        draw_placement_preview(
            screen,
            self.selected_card,
            self.selected_skill,
            self.hand,
            self
        )
        
        now = pygame.time.get_ticks()

        if now - self.start_time >= COST_ACCEL_TIME:
            current_cost_recover_time = LATE_COST_RECOVER_TIME
        else:
            current_cost_recover_time = EARLY_COST_RECOVER_TIME

        draw_game_ui(
            screen,
            font,
            self.cost,
            self.max_cost,
            self.command_points,
            self.max_command_points,
            self.hand,
            self.next_card,
            self.selected_card,
            self.selected_skill,
            self.last_cost_time,
            current_cost_recover_time,
            self.augments
        )
        
        
        if pygame.time.get_ticks() < self.ability_banner_end:

            text = big_font.render(
                self.ability_banner_text,
                True,
                (255, 230, 180)
            )

            screen.blit(
                text,
                (
                    WIDTH // 2 - text.get_width() // 2,
                    120
                )
            )
            
    
    def is_player_hq_destroyed(self):
        for building in self.buildings:
            if building.side == PLAYER and building.is_main:
                return building.hp <= 0

        return False
        
        
    def recover_cost(self, now):
        # -----------------------------
        # 생산력 회복 시스템
        #
        # 0~2분:
        # 3초당 생산력 1 회복
        #
        # 2분 이후:
        # 1.5초당 생산력 1 회복
        # -----------------------------

        if now >= COST_ACCEL_TIME:
            recover_time = LATE_COST_RECOVER_TIME
        else:
            recover_time = EARLY_COST_RECOVER_TIME

        if now - self.last_cost_time >= recover_time:
            self.last_cost_time = now

            self.cost = min(
                self.max_cost,
                self.cost + 1
            )
            

    def recover_command_points(self, now):
        # 지휘력은 22초당 1 회복
        if now - self.last_command_time >= COMMAND_POINT_RECOVER_TIME:
            self.last_command_time = now
            self.command_points = min(self.max_command_points, self.command_points + 1)
            

    def select_card(self, index):
        if index < len(self.hand):
            self.selected_card = index
            self.selected_skill = None
            

    def select_skill(self, skill_name):
        self.selected_skill = skill_name
        self.selected_card = None
        

    def place_selected(self, x, y):
        if self.selected_card is not None:
            self.place_card(x, y)

        elif self.selected_skill is not None:
            self.use_skill(x, y)
            

    def place_card(self, x, y):
        card = self.hand[self.selected_card]

        if self.cost < card["cost"]:
            return

        if not self.can_place_card(card, x, y):
            return

        self.cost -= card["cost"]

        spawn_card = card.copy()
        spawn_card["active_augments"] = self.augments.copy()

        # 중앙 건물 전용 배치 카드라면
        # 클릭한 중앙 건물 배치 구역 정보를 같이 넘김
        if spawn_card.get("center_spawn_only", False):
            spawn_card["center_spawn_x"] = x
            spawn_card["center_spawn_y"] = y

        new_units = create_units_from_card(spawn_card, x, y, PLAYER)
        self.units.extend(new_units)

        # 사용한 카드는 빠지고, 다음 카드가 손패로 들어옴
        used_card = card

        # 다음 카드가 손패로 들어옴
        replacement_card = self.draw_pile.pop(0)
        self.hand[self.selected_card] = replacement_card

        # 사용한 카드는 덱 맨 뒤로 이동
        self.draw_pile.append(used_card)

        # 다음으로 뽑힐 카드 갱신
        self.next_card = self.draw_pile[0]

        self.selected_card = None
        
        
    def can_place_card(self, card, x, y):
        
        # 중앙 건물 전용 유닛
        if card.get("center_spawn_only", False):

            for zone in CENTER_BUILDING_ZONES:
                if pygame.Rect(zone).collidepoint(x, y):
                    return True

            return False
        
        # 후방 진입로는 항상 아군 사용 가능
        for zone in PLAYER_REAR_ZONES:
            if pygame.Rect(zone).collidepoint(x, y):
                return True

        if not card.get("can_flank", False):
            return False

        # 아군 쪽 측면 진입로
        # 아군 보조 건물이 살아있을 때만 아군 사용 가능
        for i, zone in enumerate(PLAYER_FLANK_ZONES):
            if pygame.Rect(zone).collidepoint(x, y):
                lane = "left" if i == 0 else "right"
                return self.can_use_player_flank(PLAYER, lane)

        # 적 쪽 측면 진입로
        # 적 보조 건물이 파괴되었을 때 아군 사용 가능
        for i, zone in enumerate(ENEMY_FLANK_ZONES):
            if pygame.Rect(zone).collidepoint(x, y):
                lane = "left" if i == 0 else "right"
                return self.can_use_enemy_flank(PLAYER, lane)

        return False
    

    def can_place_navy(self, x, y):
        # 후방 진입로
        for zone in PLAYER_REAR_ZONES:
            if pygame.Rect(zone).collidepoint(x, y):
                return True

        # 아군 측면 진입로
        for i, zone in enumerate(PLAYER_FLANK_ZONES):
            if pygame.Rect(zone).collidepoint(x, y):
                lane = "left" if i == 0 else "right"
                return self.can_use_player_flank(PLAYER, lane)

        # 적 측면 진입로
        for i, zone in enumerate(ENEMY_FLANK_ZONES):
            if pygame.Rect(zone).collidepoint(x, y):
                lane = "left" if i == 0 else "right"
                return self.can_use_enemy_flank(PLAYER, lane)

        return False
    
        
    def use_skill(self, x, y):
        
        if self.selected_skill == "tiger":
            self.spawn_tiger(x, y)
            self.selected_skill = None
            return
            
        if self.selected_skill == "bombardment":
            if self.command_points < BOMBARDMENT_COST:
                return

            self.command_points -= BOMBARDMENT_COST
            self.commander.call_bombardment(x, y, self.shells)

        elif self.selected_skill == "navy":
            if self.command_points < NAVY_SKILL_COST:
                return
            
            if not self.can_place_navy(x, y):
                return

            self.command_points -= NAVY_SKILL_COST

            # -----------------------------
            # 야마모토 지휘 스킬 2
            # 일본 제국 해군 분대 소환
            # -----------------------------

            new_units = create_units_from_card(
                NAVY_SQUAD,
                x,
                y,
                PLAYER
            )

            self.units.extend(new_units)

        # 스킬 사용 후 선택 해제
        self.selected_skill = None
        
    def spawn_tiger(self, x, y):
        if self.command_points < 5:
            return

        self.command_points -= 5

        card = TIGER_CARD.copy()
        card["active_augments"] = self.augments.copy()

        units = create_units_from_card(card, x, y, PLAYER)
        self.units.extend(units)

        self.show_ability_banner("티거 투입")
        
        
    def update_side_lane_control(self):

        # -----------------------------
        # 기본값
        # -----------------------------

        self.left_lane_owner = PLAYER
        self.right_lane_owner = PLAYER

        # -----------------------------
        # 적 좌측 타워 생존 여부
        # -----------------------------

        enemy_left_alive = False

        # -----------------------------
        # 적 우측 타워 생존 여부
        # -----------------------------

        enemy_right_alive = False

        for building in self.buildings:

            if building.hp <= 0:
                continue

            # -----------------------------
            # 적 좌측 타워
            # -----------------------------

            if (
                building.side == ENEMY
                and building.name == "Enemy Left Tower"
            ):
                enemy_left_alive = True

            # -----------------------------
            # 적 우측 타워
            # -----------------------------

            elif (
                building.side == ENEMY
                and building.name == "Enemy Right Tower"
            ):
                enemy_right_alive = True

        # -----------------------------
        # 적 좌측 타워 파괴
        # → 플레이어가 좌측 측면 사용 가능
        # -----------------------------

        if not enemy_left_alive:
            self.left_lane_owner = PLAYER
        else:
            self.left_lane_owner = ENEMY

        # -----------------------------
        # 적 우측 타워 파괴
        # → 플레이어가 우측 측면 사용 가능
        # -----------------------------

        if not enemy_right_alive:
            self.right_lane_owner = PLAYER
        else:
            self.right_lane_owner = ENEMY
            
    def can_use_side_lane(self, side, lane):

        if lane == "left":
            return self.left_lane_owner == side

        elif lane == "right":
            return self.right_lane_owner == side

        return False
    
    def can_use_player_flank(self, side, lane):
        tower_name = "Player Left Tower" if lane == "left" else "Player Right Tower"

        tower_alive = any(
            building.name == tower_name and building.hp > 0
            for building in self.buildings
        )

        # 아군 타워 생존: 아군 사용 가능
        # 아군 타워 파괴: 적만 사용 가능
        if tower_alive:
            return side == PLAYER
        else:
            return side == ENEMY


    def can_use_enemy_flank(self, side, lane):
        tower_name = "Enemy Left Tower" if lane == "left" else "Enemy Right Tower"

        tower_alive = any(
            building.name == tower_name and building.hp > 0
            for building in self.buildings
        )

        # 적 타워 생존: 적 사용 가능
        # 적 타워 파괴: 아군 사용 가능
        if tower_alive:
            return side == ENEMY
        else:
            return side == PLAYER
    def apply_army_academy_training(self):
        pass
        
    def apply_augment(self, augment):
        augment_id = augment["id"]
        
        if augment_id in self.augments:
            return
        
        self.augments.append(augment_id)

        if augment["id"] == "suicide_flank":
            for card in self.hand + self.draw_pile:
                if card["name"] == "자폭병":
                    card["can_flank"] = True

        elif augment["id"] == "anti_tank_grenade":
            for card in self.hand + self.draw_pile:
                if "수류탄" in card.get("abilities", []):
                    card["grenade_damage_bonus"] = 1.5
                    
        elif augment_id == "western_tiger":
            self.waiting_tiger_skill_choice = True

        elif augment_id == "captured_weapons":
            self.apply_captured_weapons()

        elif augment_id == "army_academy_training":
            self.apply_army_academy_training()
            
        elif augment_id == "manchukuo_extra_conscription":
            for card in self.hand + self.draw_pile:
                if card["id"] == "manchukuo_troops":
                    card["count"] = 14
                    for key in card["damage"]:
                        card["damage"][key] = int(card["damage"][key] * 0.8)
                        
        elif augment_id == "death_defying_spirit":
            pass
        
        elif augment_id == "inhuman_ideology":
            pass
                        
            
    def generate_augment_choices(self):

        available = [
            aug for aug in AUGMENTS
            if aug["id"] not in self.augments
        ]

        self.augment_choices = random.sample(
            available,
            min(3, len(available))
        )
            
    def apply_captured_weapons(self):
        for card in self.hand + self.draw_pile:
            if card["id"] == "night_raiders":
                card["damage"] = {
                    TYPE_INFANTRY: 51,
                    TYPE_VEHICLE: 21,
                    TYPE_TANK: 9,
                    TYPE_BUILDING: 30,
                }
                card["attack_delay"] = 150
                card["attack_range"] = 60
                card["preferred_range"] = 40
                card["weapon"] = "PPSH"

            elif card["id"] == "ambush_squad":  # 매복대 id에 맞게 수정
                card["damage"] = {
                    TYPE_INFANTRY: 93,
                    TYPE_VEHICLE: 63,
                    TYPE_TANK: 10,
                    TYPE_BUILDING: 60,
                }
                card["attack_delay"] = 650
                card["attack_range"] = 90
                card["preferred_range"] = 90
                card["weapon"] = "BAR"
                
    def destroy_enemy_main_base(self):
        for building in self.buildings:
            if building.side == ENEMY and getattr(building, "is_main", False):
                building.hp = 0
                return
            
    def trigger_stage_event(self):
        stage = getattr(self, "current_stage", getattr(self, "stage", 1))

        if stage == 1:
            self.last_stage1_event = -999999
            self.update_stage1_event()

        elif stage == 2:
            self.last_partisan_spawn = -999999
            self.update_stage2_event()
            
    def reapply_augments(self):
        current_augments = self.augments.copy()
        self.augments = []

        for augment_id in current_augments:
            for aug in AUGMENTS:
                if aug["id"] == augment_id:
                    self.apply_augment(aug)
                    break