# ui.py

import pygame
import random
import os
from settings import *
from utils import draw_text
from augments import AUGMENTS

CARD_IMAGE_CACHE = {}

augment_hover_index = None
augment_hover_start = 0

def get_card_image(path, size):
    key = (path, size)

    if key not in CARD_IMAGE_CACHE:
        img = pygame.image.load(path).convert_alpha()
        img = pygame.transform.smoothscale(img, size)
        CARD_IMAGE_CACHE[key] = img

    return CARD_IMAGE_CACHE[key]

def draw_wrapped_text(screen, font, text, x, y, color, max_width, line_gap=22):
    words = text.split(" ")
    line = ""

    for word in words:
        test_line = line + word + " "

        if font.size(test_line)[0] > max_width:
            draw_text(screen, font, line, x, y, color)
            y += line_gap
            line = word + " "
        else:
            line = test_line

    if line:
        draw_text(screen, font, line, x, y, color)


def draw_select_screen(screen, font, big_font):
    screen.fill((25, 35, 50))

    draw_text(screen, big_font, "지휘관 선택", 390, 80, WHITE)

    card = pygame.Rect(365, 180, 270, 460)
    pygame.draw.rect(screen, (25,25,25), (365,160,270,460))
    pygame.draw.rect(screen, WHITE, (365,160,270,460), 2)

    portrait = pygame.image.load(
        "assets/commanders/officer_portrait.png"
    ).convert_alpha()

    portrait = pygame.transform.smoothscale(
        portrait,
        (160, 160)
    )

    screen.blit(portrait, (420, 170))
    draw_text(screen, font, "야마모토 이소로쿠", 422, 330, WHITE)
    draw_text(screen, font, "해군 연합 함대", 437, 370, YELLOW)

    draw_text(screen, font, "1번: 해안 포격 / 지휘력 3", 400, 420, WHITE)
    draw_text(screen, font, "2번: 해군 배치 / 지휘력 2", 400, 450, WHITE)

    draw_text(screen, font, "클릭해서 선택", 440, 540, ORANGE)


def is_commander_card_clicked(mx, my):
    return 380 <= mx <= 620 and 350 <= my <= 460

def is_stage_exit_clicked(mx, my):
    return pygame.Rect(380, 440, 240, 55).collidepoint(mx, my)


def draw_battlefield(screen, font):
    screen.fill((54, 82, 55))

    # -----------------------------
    # 양쪽 도로
    # 중앙은 건물이 있는 구역이므로 길이 아님
    # -----------------------------

    # -----------------------------
    # 중앙 장애물 건물
    # 라인을 간접적으로 분리하는 역할
    # -----------------------------

    center_obstacle = pygame.Rect(410, 220, 180, 220)

    pygame.draw.rect(screen, (55, 65, 55), center_obstacle)
    pygame.draw.rect(screen, (30, 40, 30), center_obstacle, 4)

    draw_text(screen, font, "중앙 건물", 455, 325, GRAY)


def draw_game_ui(
    screen,
    font,
    cost,
    max_cost,
    command_points,
    max_command_points,
    hand,
    next_card,
    selected_card,
    selected_skill,
    last_cost_time,
    cost_recover_time,
    active_augments
):
    
    # 하단 UI 검은 패널
    pygame.draw.rect(
        screen,
        (10, 10, 10),
        (0, UI_TOP, WIDTH, HEIGHT - UI_TOP)
    )

    pygame.draw.line(
        screen,
        WHITE,
        (0, UI_TOP),
        (WIDTH, UI_TOP),
        2
    )
    
    # -----------------------------
    # 지휘관 초상화
    # -----------------------------
    
    portrait_rect = pygame.Rect(10, 670, 145, 145)

    if not hasattr(draw_game_ui, "commander_portrait"):

        img = pygame.image.load(
            "assets/commanders/officer_portrait.png"
        ).convert_alpha()

        draw_game_ui.commander_portrait = pygame.transform.smoothscale(
            img,
            (140, 140)
        )

    pygame.draw.rect(screen, (20,30,20), portrait_rect)
    pygame.draw.rect(screen, WHITE, portrait_rect, 2)

    screen.blit(
        draw_game_ui.commander_portrait,
        (portrait_rect.x + 3, portrait_rect.y + 3)
    )
    
    # -----------------------------
    # 오른쪽 아래 지휘 능력 UI
    # -----------------------------

    cmd_panel = pygame.Rect(765, 670, 180, 110)

    pygame.draw.rect(screen, (25, 22, 18), cmd_panel)
    pygame.draw.rect(screen, WHITE, cmd_panel, 2)

    draw_text(screen, font, "지휘력", cmd_panel.x + 14, cmd_panel.y + 8, YELLOW)
    draw_text(
        screen,
        font,
        f"{command_points}/{max_command_points}",
        cmd_panel.x + 75,
        cmd_panel.y + 6,
        WHITE
    )

    skill1 = pygame.Rect(cmd_panel.x + 7, cmd_panel.y + 38, 90, 28)
    skill2 = pygame.Rect(cmd_panel.x + 7, cmd_panel.y + 73, 108, 28)

    pygame.draw.rect(screen, ORANGE if selected_skill == "bombardment" else DARK, skill1)
    pygame.draw.rect(screen, BLUE if selected_skill == "navy" else DARK, skill2)

    pygame.draw.rect(screen, WHITE, skill1, 1)
    pygame.draw.rect(screen, WHITE, skill2, 1)

    draw_text(screen, font, "해안 포격", skill1.x + 6, skill1.y + 2, WHITE)
    draw_text(screen, font, "해군대 증원", skill2.x + 6, skill2.y + 2, WHITE)

    # 다음 카드
    next_rect = pygame.Rect(170, 670, 115, 145)
    pygame.draw.rect(screen, (30, 100, 30), next_rect)
    pygame.draw.rect(screen, WHITE, next_rect, 2)

    draw_text(screen, font, "다음", next_rect.x + 43, next_rect.y + 8, GRAY)
    
    image_rect = pygame.Rect(
            next_rect.x + 8,
            next_rect.y + 32,
            next_rect.w - 16,
            next_rect.h - 35
        )

    if next_card:
        if next_card.get("image"):
            img = get_card_image(next_card["image"], (image_rect.w, image_rect.h))
            screen.blit(img, image_rect)
        else:
            draw_text(screen, font, next_card["name"], image_rect.x + 5, image_rect.y + 40, WHITE)

    # 코스트 바
    now = pygame.time.get_ticks()

    if cost >= max_cost:
        progress = 1
    else:
        progress = (now - last_cost_time) / cost_recover_time
        progress = max(0, min(1, progress))

    bar_x = 290
    bar_y = 795
    bar_w = 520
    bar_h = 22

    EMPTY_COST = (5, 5, 5)
    COST_FILLED = (190, 135, 65)
    COST_CHARGING = (255, 205, 105)
    COST_BORDER = (95, 75, 45)

    pygame.draw.rect(screen, (0, 0, 0), (bar_x - 3, bar_y - 3, bar_w + 6, bar_h + 6))
    pygame.draw.rect(screen, COST_BORDER, (bar_x - 3, bar_y - 3, bar_w + 6, bar_h + 6), 2)

    cell_w = bar_w / max_cost

    for i in range(max_cost):
        cell_x = bar_x + int(i * cell_w)
        cell_rect = pygame.Rect(cell_x + 2, bar_y + 2, int(cell_w) - 4, bar_h - 4)

        # 빈 칸은 반드시 검은색으로 먼저 채움
        pygame.draw.rect(screen, EMPTY_COST, cell_rect)

        if i < int(cost):
            pygame.draw.rect(screen, COST_FILLED, cell_rect)

        pygame.draw.rect(screen, COST_BORDER, cell_rect, 1)

    # 충전 중인 칸
    if cost < max_cost:
        cell_x = bar_x + int(int(cost) * cell_w)
        fill_w = int((int(cell_w) - 4) * progress)

        pygame.draw.rect(
            screen,
            COST_CHARGING,
            (cell_x + 2, bar_y + 2, fill_w, bar_h - 4)
        )

    draw_text(screen, font, f"{int(cost)}/{max_cost}", bar_x + bar_w + 18, bar_y - 1, WHITE)
    # 카드 4장
    keys = ["Q", "W", "E", "R"]
    start_x = 305
    
    card_y = 665
    card_w = 105
    card_h = 125

    for i, card in enumerate(hand):
        rect = pygame.Rect(start_x + i * 115, card_y, card_w, card_h)

        image_rect = rect

        if card.get("image"):
            img = get_card_image(card["image"], (image_rect.w, image_rect.h))
            screen.blit(img, image_rect)
        else:
            draw_text(screen, font, card["name"], rect.x + 7, rect.y + 65, WHITE)
            draw_text(screen, font, f"{card['cost']}", rect.x + rect.w - 22, rect.y + 4, GREEN)
            
        if selected_card == i:
            pygame.draw.rect(screen, YELLOW, rect, 3)
        elif not card.get("image"):
            pygame.draw.rect(screen, WHITE, rect, 2)


def draw_placement_preview(screen, selected_card, selected_skill, hand=None, game=None):
    mx, my = pygame.mouse.get_pos()

    if selected_card is None and selected_skill is None:
        return

    # 마우스 위치 표시
    pygame.draw.circle(screen, YELLOW, (mx, my), 18, 2)

    # -----------------------------
    # 카드 선택 시 배치 가능 진입로 표시
    # -----------------------------
    if selected_card is not None and hand is not None:
        card = hand[selected_card]

        # -----------------------------
        # 중앙 건물 전용 카드
        # 후방/측면 진입로를 그리기 전에 먼저 처리
        # -----------------------------
        if card.get("center_spawn_only", False):
            for zone in CENTER_BUILDING_ZONES:
                rect = pygame.Rect(zone)
                pygame.draw.rect(screen, (255, 220, 120), rect, 3)

                glow = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
                glow.fill((255, 220, 120, 60))
                screen.blit(glow, rect.topleft)

            return

        # -----------------------------
        # 일반 카드: 후방 진입로 표시
        # -----------------------------
        for zone in PLAYER_REAR_ZONES:
            rect = pygame.Rect(zone)
            pygame.draw.rect(screen, (80, 220, 100), rect, 3)

            glow = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
            glow.fill((80, 220, 100, 45))
            screen.blit(glow, rect.topleft)

        # -----------------------------
        # 측면 진입 가능한 카드만 측면 진입로 표시
        # -----------------------------
        if card.get("can_flank", False) and game is not None:
            for i, zone in enumerate(PLAYER_FLANK_ZONES):
                lane = "left" if i == 0 else "right"

                if game.can_use_player_flank(PLAYER, lane):
                    rect = pygame.Rect(zone)
                    pygame.draw.rect(screen, (80, 150, 255), rect, 3)

                    glow = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
                    glow.fill((80, 150, 255, 55))
                    screen.blit(glow, rect.topleft)

            for i, zone in enumerate(ENEMY_FLANK_ZONES):
                lane = "left" if i == 0 else "right"

                if game.can_use_enemy_flank(PLAYER, lane):
                    rect = pygame.Rect(zone)
                    pygame.draw.rect(screen, (255, 180, 80), rect, 3)

                    glow = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
                    glow.fill((255, 180, 80, 55))
                    screen.blit(glow, rect.topleft)
                
                
        # -----------------------------
        # 지휘 스킬 선택 시 배치 가능 지역 표시
        # -----------------------------
    if selected_skill == "navy" and game is not None:
        for zone in PLAYER_REAR_ZONES:
            rect = pygame.Rect(zone)
            pygame.draw.rect(screen, (80, 220, 100), rect, 3)

            glow = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
            glow.fill((80, 220, 100, 45))
            screen.blit(glow, rect.topleft)

        for i, zone in enumerate(PLAYER_FLANK_ZONES):
            lane = "left" if i == 0 else "right"

            if game.can_use_player_flank(PLAYER, lane):
                rect = pygame.Rect(zone)
                pygame.draw.rect(screen, (80, 150, 255), rect, 3)

                glow = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
                glow.fill((80, 150, 255, 55))
                screen.blit(glow, rect.topleft)

        for i, zone in enumerate(ENEMY_FLANK_ZONES):
            lane = "left" if i == 0 else "right"

            if game.can_use_enemy_flank(PLAYER, lane):
                rect = pygame.Rect(zone)
                pygame.draw.rect(screen, (255, 180, 80), rect, 3)

                glow = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
                glow.fill((255, 180, 80, 55))
                screen.blit(glow, rect.topleft)
                
                
def draw_main_menu(screen, font, big_font, selected_menu):

    screen.fill((20, 20, 20))

    title = big_font.render(
        "PACIFIC FRONT",
        True,
        (230, 220, 180)
    )

    screen.blit(
        title,
        (
            WIDTH // 2 - title.get_width() // 2,
            120
        )
    )

    save_exists = os.path.exists("save.json")

    menu_items = [
        ("새 게임", WHITE),
        ("이어하기", WHITE if save_exists else GRAY),
        ("단축키", WHITE),
        ("설정", WHITE),
        ("게임 나가기", WHITE),
    ]

    start_y = 280

    for i, (text, color) in enumerate(menu_items):

        txt = font.render(text, True, color)

        screen.blit(
            txt,
            (
                WIDTH // 2 - txt.get_width() // 2,
                start_y + i * 60
            )
        )
        
def draw_shortcuts(screen, font, big_font):

    screen.fill((20,20,20))

    draw_text(screen, big_font, "단축키", 430, 80, WHITE)

    controls = [
        "QWER : 카드 선택",
        "1 : 해안 포격",
        "2 : 해군대 증원",
        "ESC : 메뉴",
    ]

    for i, text in enumerate(controls):

        draw_text(
            screen,
            font,
            text,
            340,
            220 + i * 50,
            WHITE
        )
            
#스테이지
def draw_stage_screen(screen, font, big_font, current_stage, active_augments):
    screen.fill((25, 35, 45))

    draw_text(screen, big_font, "스테이지 선택", 370, 80, WHITE)
    draw_text(screen, font, f"현재 스테이지: {current_stage} / {MAX_STAGE}", 420, 160, YELLOW)

    start_button = pygame.Rect(380, 300, 240, 80)
    pygame.draw.rect(screen, DARK, start_button)
    pygame.draw.rect(screen, WHITE, start_button, 3)

    draw_text(screen, font, "전투 시작", 455, 330, WHITE)
    
    exit_button = pygame.Rect(380, 440, 240, 55)

    pygame.draw.rect(screen, (80, 30, 30), exit_button)
    pygame.draw.rect(screen, WHITE, exit_button, 2)

    draw_text(screen, font, "게임 나가기", 455, 458, WHITE)
    
    mx, my = pygame.mouse.get_pos()
    now = pygame.time.get_ticks()

    if not hasattr(draw_stage_screen, "hover_index"):
        draw_stage_screen.hover_index = None
        draw_stage_screen.hover_start = 0

    augment_x = 80
    augment_y = 600
    augment_w = 180
    augment_h = 50

    for i, augment_id in enumerate(active_augments):
        augment = None

        for aug in AUGMENTS:
            if aug["id"] == augment_id:
                augment = aug
                break

        if augment is None:
            continue

        rect = pygame.Rect(
            augment_x + i * 200,
            augment_y,
            augment_w,
            augment_h
        )

        hovering = rect.collidepoint(mx, my)

        if hovering:
            if draw_stage_screen.hover_index != i:
                draw_stage_screen.hover_index = i
                draw_stage_screen.hover_start = now
        elif draw_stage_screen.hover_index == i:
            draw_stage_screen.hover_index = None
            draw_stage_screen.hover_start = 0

        pygame.draw.rect(screen, DARK, rect)
        pygame.draw.rect(screen, YELLOW if hovering else WHITE, rect, 2)

        draw_text(screen, font, "?", rect.x + 12, rect.y + 14, YELLOW)
        draw_text(screen, font, augment["name"], rect.x + 42, rect.y + 14, WHITE)


def is_stage_start_clicked(mx, my):
    return 380 <= mx <= 620 and 300 <= my <= 380


def draw_reward_screen(screen, font, big_font, current_stage):
    screen.fill((35, 30, 40))

    draw_text(screen, big_font, "보상 선택", 410, 70, WHITE)

    rewards = [
        pygame.Rect(190, 250, 170, 210),
        pygame.Rect(415, 250, 170, 210),
        pygame.Rect(640, 250, 170, 210),
    ]

    labels = ["? 카드", "? 카드", "? 증강"]

    for i, rect in enumerate(rewards):
        pygame.draw.rect(screen, DARK, rect)
        pygame.draw.rect(screen, WHITE, rect, 3)
        draw_text(screen, big_font, "?", rect.x + 70, rect.y + 55, YELLOW)
        draw_text(screen, font, labels[i], rect.x + 50, rect.y + 145, WHITE)

    draw_text(screen, font, "보상을 클릭하면 다음 스테이지로 이동", 350, 520, WHITE)


def get_reward_clicked(mx, my):
    rewards = [
        pygame.Rect(190, 250, 170, 210),
        pygame.Rect(415, 250, 170, 210),
        pygame.Rect(640, 250, 170, 210),
    ]

    for i, rect in enumerate(rewards):
        if rect.collidepoint(mx, my):
            return i

    return None

def get_game_over_clicked(mx, my):
    retry_button = pygame.Rect(370, 330, 260, 60)
    exit_button = pygame.Rect(370, 410, 260, 60)

    if retry_button.collidepoint(mx, my):
        return "retry"

    if exit_button.collidepoint(mx, my):
        return "exit"

    return None

def draw_game_over_screen(screen, font, big_font):
    screen.fill((15, 15, 15))

    draw_text(screen, big_font, "GAME OVER", 380, 180, RED)

    retry_button = pygame.Rect(370, 330, 260, 60)
    exit_button = pygame.Rect(370, 410, 260, 60)

    pygame.draw.rect(screen, DARK, retry_button)
    pygame.draw.rect(screen, WHITE, retry_button, 2)

    pygame.draw.rect(screen, DARK, exit_button)
    pygame.draw.rect(screen, WHITE, exit_button, 2)

    draw_text(screen, font, "다시 하기", 460, 350, WHITE)
    draw_text(screen, font, "나가기", 470, 430, WHITE)

def draw_card_reward_screen(screen, font, big_font):
    screen.fill((30, 35, 45))

    draw_text(screen, big_font, "카드 보상 선택", 350, 70, WHITE)

    rewards = [
        pygame.Rect(170, 220, 180, 240),
        pygame.Rect(410, 220, 180, 240),
        pygame.Rect(650, 220, 180, 240),
    ]

    for rect in rewards:
        pygame.draw.rect(screen, DARK, rect)
        pygame.draw.rect(screen, WHITE, rect, 3)

        draw_text(
            screen,
            big_font,
            "?",
            rect.x + 70,
            rect.y + 70,
            YELLOW
        )

        draw_text(
            screen,
            font,
            "새 카드",
            rect.x + 55,
            rect.y + 170,
            WHITE
        )
        
def draw_augment_reward_screen(screen, font, big_font, augment_pick_count, augments):
    global augment_hover_index, augment_hover_start

    screen.fill((18, 18, 18))

    draw_text(screen, big_font, "증강 선택", 390, 80, WHITE)
    draw_text(screen, font, f"{augment_pick_count + 1}/2 선택", 450, 130, YELLOW)

    mx, my = pygame.mouse.get_pos()
    now = pygame.time.get_ticks()

    for i, augment in enumerate(augments):
        rect = pygame.Rect(190 + i * 220, 240, 180, 230)

        hovering = rect.collidepoint(mx, my)

        if hovering:
            if augment_hover_index != i:
                augment_hover_index = i
                augment_hover_start = now
        elif augment_hover_index == i:
            augment_hover_index = None
            augment_hover_start = 0

        pygame.draw.rect(screen, DARK, rect)
        pygame.draw.rect(screen, YELLOW if hovering else WHITE, rect, 2)

        draw_text(screen, big_font, "?", rect.x + 72, rect.y + 45, WHITE)
        draw_text(screen, font, augment["name"], rect.x + 18, rect.y + 145, WHITE)

        if hovering:
            progress = min(1, (now - augment_hover_start) / 1000)
            pygame.draw.rect(screen, BLACK, (rect.x + 15, rect.y + 205, 150, 8))
            pygame.draw.rect(screen, WHITE, (rect.x + 15, rect.y + 205, int(150 * progress), 8))

            if progress >= 1:
                desc_width = 360
                padding = 12
                line_gap = 22

                lines = wrap_text(font, augment["description"], desc_width - padding * 2)

                desc_height = padding * 2 + len(lines) * line_gap

                desc_x = rect.x
                desc_y = rect.y + rect.h + 18

                # 화면 오른쪽 밖으로 나가지 않게
                if desc_x + desc_width > WIDTH:
                    desc_x = WIDTH - desc_width - 10

                # 화면 아래 밖으로 나가지 않게
                if desc_y + desc_height > HEIGHT:
                    desc_y = rect.y - desc_height - 18

                desc_rect = pygame.Rect(desc_x, desc_y, desc_width, desc_height)

                pygame.draw.rect(screen, (25, 25, 25), desc_rect)
                pygame.draw.rect(screen, WHITE, desc_rect, 2)

                for i, line in enumerate(lines):
                    draw_text(
                        screen,
                        font,
                        line,
                        desc_rect.x + padding,
                        desc_rect.y + padding + i * line_gap,
                        WHITE
                    )
                
def get_augment_clicked(mx, my, augments):
    for i, augment in enumerate(augments):
        rect = pygame.Rect(190 + i * 220, 240, 180, 230)
        if rect.collidepoint(mx, my):
            return augment
    return None

def wrap_text(font, text, max_width):
    words = text.split(" ")
    lines = []
    line = ""

    for word in words:
        test = line + word + " "

        if font.size(test)[0] > max_width and line:
            lines.append(line.strip())
            line = word + " "
        else:
            line = test

    if line:
        lines.append(line.strip())

    return lines