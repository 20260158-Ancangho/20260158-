AUGMENTS = [
    {
        "id": "suicide_flank",
        "name": "자폭병 매복 배치",
        "description": "자폭병을 측면 배치 시킬 수 있습니다.",
    },
    {
        "id": "banzai_defense",
        "name": "반자이 어택",
        "description": "돌격, 반자이 돌격 특수 능력을 가진 카드들은 받는 피해가 10% 감소합니다.",
    },
    {
        "id": "anti_tank_grenade",
        "name": "대전차 수류탄",
        "description": "수류탄을 던지는 카드와 지휘 능력 유닛의 수류탄 데미지가 50% 증가합니다.",
    },
    {
        "id": "encouragement",
        "name": "독려",
        "description": "일본군 장교의 돌격 적용 오라 범위 안 아군에게 야마토 정신을 부여합니다.",
    },
    {
        "id": "western_tiger",
        "name": "서방에서 온 호랑이",
        "description": "지휘 능력 하나를 지휘력 5의 티거 투입으로 변경합니다.",
    },
    {
        "id": "death_defying_spirit",
        "name": "죽음을 무릎 쓴 정신력",
        "description": "야마토 정신을 가진 모든 유닛이 받는 피해가 10% 감소합니다.",
    },
    {
        "id": "inhuman_ideology",
        "name": "인외사상",
        "description": "반자이 돌격의 체력 조건을 삭제하고, 반자이 돌격 보유 유닛의 공격력이 20% 증가합니다.",
    },
    {
        "id": "army_academy_training",
        "name": "육군 사관학교 훈련",
        "description": "장교 체력이 30% 증가하고, 자폭을 제외한 모든 근접 공격 피해가 20% 증가합니다.",
    },
    {
        "id": "captured_weapons",
        "name": "노획제 무기",
        "description": "야습대는 PPSH, 매복대는 BAR로 무장이 변경됩니다.",
    },
    {
        "id": "manchukuo_extra_conscription",
        "name": "만주군 추가 징집",
        "description": "만주군 부대의 인원이 10명에서 14명으로 늘어나는 대신 공격력이 20% 감소합니다.",
    },
]