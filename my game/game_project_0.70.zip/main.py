#main.py

import pygame
import os
import json

from settings import *
from ui import (
    draw_select_screen,
    is_commander_card_clicked,
    draw_stage_screen,
    is_stage_start_clicked,
    draw_card_reward_screen,
    draw_augment_reward_screen,
    get_reward_clicked,
    get_augment_clicked,
    draw_main_menu,
    is_stage_exit_clicked,
    draw_game_over_screen,
    get_game_over_clicked,
)
from game_manager import Game


pygame.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("WW2 RTS Prototype - Card System")

clock = pygame.time.Clock()

font = pygame.font.SysFont("malgungothic", 18)
big_font = pygame.font.SysFont("malgungothic", 42)

game_state = STATE_MENU
game = None
current_stage = 1
augment_pick_count = 0
selected_menu = 0

running = True

while running:
    clock.tick(FPS)

    # -----------------------------
    # 이벤트 처리
    # -----------------------------

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False
            
        if game_state == STATE_MENU:

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_UP:
                    selected_menu = max(0, selected_menu - 1)

                elif event.key == pygame.K_DOWN:
                    selected_menu = min(4, selected_menu + 1)

                elif event.key == pygame.K_RETURN:

                    # 새 게임
                    if selected_menu == 0:
                        if os.path.exists("save.json"):
                            os.remove("save.json")

                        current_stage = 1
                        game = None
                        game_state = STATE_SELECT

                    # 이어하기
                    elif selected_menu == 1:

                        if os.path.exists("save.json"):

                            game = Game()
                            game.load_game()

                            game_state = STATE_GAME

                    # 단축키
                    elif selected_menu == 2:
                        game_state = STATE_SHORTCUTS

                    # 설정
                    elif selected_menu == 3:
                        game_state = STATE_SETTINGS

                    # 종료
                    elif selected_menu == 4:
                        running = False
                        
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                menu_start_y = 280
                menu_gap = 60

                for i in range(5):
                    rect = pygame.Rect(
                        WIDTH // 2 - 120,
                        menu_start_y + i * menu_gap - 10,
                        240,
                        40
                    )

                    if rect.collidepoint(mx, my):
                        selected_menu = i

                        if selected_menu == 0:
                            if os.path.exists("save.json"):
                                os.remove("save.json")

                            current_stage = 1
                            game = None
                            game_state = STATE_SELECT

                        elif selected_menu == 1:
                            if os.path.exists("save.json"):
                                game = Game()
                                game.load_game()
                                game_state = STATE_GAME

                        elif selected_menu == 2:
                            game_state = STATE_SHORTCUTS

                        elif selected_menu == 3:
                            game_state = STATE_SETTINGS

                        elif selected_menu == 4:
                            running = False

        # -----------------------------
        # 지휘관 선택
        # -----------------------------

        if game_state == STATE_SELECT:

            if event.type == pygame.MOUSEBUTTONDOWN:

                mx, my = pygame.mouse.get_pos()

                if is_commander_card_clicked(mx, my):

                    game = Game(current_stage)
                    game_state = STATE_STAGE
        
        #스테이지 시작 
        elif game_state == STATE_STAGE:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                if is_stage_start_clicked(mx, my):
                    game = Game(current_stage)
                    game_state = STATE_GAME
                    
                elif is_stage_exit_clicked(mx, my):
                    running = False
                    
        elif game_state == STATE_CARD_REWARD:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                reward = get_reward_clicked(mx, my)

                if reward is not None:
                    augment_pick_count = 0
                    game.generate_augment_choices()
                    game_state = STATE_AUGMENT_REWARD

        elif game_state == STATE_AUGMENT_REWARD:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()

                reward = get_augment_clicked(mx, my, game.augment_choices)

                if reward is not None:
                    game.apply_augment(reward)
                    augment_pick_count += 1

                    if augment_pick_count < 2:
                        game.generate_augment_choices()
                    else:
                        saved_augments = game.augments.copy()
                        current_stage += 1
                        augment_pick_count = 0

                        if current_stage > MAX_STAGE:
                            current_stage = 1
                            game_state = STATE_SELECT
                        else:
                            game = Game(current_stage)
                            game.augments = saved_augments
                            game.reapply_augments()
                            game_state = STATE_STAGE
        
        # -----------------------------
        # 실제 게임
        # -----------------------------

        elif game_state == STATE_GAME:

            if event.type == pygame.KEYDOWN:
                
                if game.waiting_tiger_skill_choice:
                    if event.key == pygame.K_1:
                        game.tiger_skill_slot = 1
                        game.waiting_tiger_skill_choice = False

                    elif event.key == pygame.K_2:
                        game.tiger_skill_slot = 2
                        game.waiting_tiger_skill_choice = False

                    continue

                if event.key == pygame.K_1:
                    if game.selected_skill == "bombardment":
                        game.selected_skill = None
                    else:
                        game.selected_skill = "bombardment"
                    game.selected_card = None

                elif event.key == pygame.K_2:
                    if game.selected_skill == "navy" and game is not None:
                        game.selected_skill = None
                    else:
                        game.selected_skill = "navy"
                    game.selected_card = None
                    
                if event.key == pygame.K_1:
                    if game.tiger_skill_slot == 1:
                        game.selected_skill = "tiger"
                    else:
                        game.selected_skill = "bombardment"

                elif event.key == pygame.K_2:
                    if game.tiger_skill_slot == 2:
                        game.selected_skill = "tiger"
                    else:
                        game.selected_skill = "navy"

                elif event.key == pygame.K_q:
                    game.selected_card = None if game.selected_card == 0 else 0
                    game.selected_skill = None

                elif event.key == pygame.K_w:
                    game.selected_card = None if game.selected_card == 1 else 1
                    game.selected_skill = None

                elif event.key == pygame.K_e:
                    game.selected_card = None if game.selected_card == 2 else 2
                    game.selected_skill = None

                elif event.key == pygame.K_r:
                    game.selected_card = None if game.selected_card == 3 else 3
                    game.selected_skill = None

                elif event.key == pygame.K_ESCAPE:
                    game.selected_card = None
                    game.selected_skill = None
                    
                # 디버그: 스테이지 즉시 클리어
                elif event.key == pygame.K_k:
                    game.destroy_enemy_main_base()

                # 디버그: 현재 스테이지 기믹 즉시 발동
                elif event.key == pygame.K_i:
                    game.trigger_stage_event()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    mx, my = pygame.mouse.get_pos()
                    game.place_selected(mx, my)
                    
            #카드 보상 처리
            elif game_state == STATE_CARD_REWARD:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()

                    reward = get_augment_clicked(mx, my, game.augment_choices)
                    
                    if reward is not None:
                        game_state = STATE_AUGMENT_REWARD
                       
                       
            elif game_state == STATE_AUGMENT_REWARD:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = pygame.mouse.get_pos()

                    reward = get_augment_clicked(mx, my, game.augment_choices)

                    if reward is not None:
                        game.apply_augment(reward)
                        current_stage += 1

                        if current_stage > MAX_STAGE:
                            current_stage = 1
                            game_state = STATE_SELECT
                        else:
                            game = Game(current_stage)
                            game_state = STATE_STAGE
                            
                reward = get_augment_clicked(mx, my, game.augment_choices)

                if reward is not None:
                    game.apply_augment(reward)

                    augment_pick_count += 1

                    if augment_pick_count < 2:
                        game.generate_augment_choices()
                    else:
                        augment_pick_count = 0
                        current_stage += 1

                        if current_stage > MAX_STAGE:
                            current_stage = 1
                            game_state = STATE_SELECT
                        else:
                            game = Game(current_stage)
                            game_state = STATE_STAGE
                            
            # -----------------------------
            # 게임 오버
            # -----------------------------

            elif game_state == STATE_GAME_OVER:

                if event.type == pygame.MOUSEBUTTONDOWN:

                    mx, my = pygame.mouse.get_pos()

                    result = get_game_over_clicked(mx, my)

                    if result == "retry":
                        game = Game(current_stage)
                        game_state = STATE_GAME

                    elif result == "exit":
                        running = False
                            
        if game_state == STATE_GAME:
            game.save_game()

    # -----------------------------
    # 화면 그리기
    # -----------------------------

    screen.fill((20, 20, 20))

    if game_state == STATE_MENU:
        draw_main_menu(screen, font, big_font, selected_menu)

    elif game_state == STATE_SELECT:
        draw_select_screen(screen, font, big_font)
        
    elif game_state == STATE_STAGE:
        draw_stage_screen(screen, font, big_font, current_stage, game.augments if game else [])

    elif game_state == STATE_GAME:

        game.update()

        if game.is_player_hq_destroyed():
            game_state = STATE_GAME_OVER

        elif game.is_stage_cleared():
            game_state = STATE_CARD_REWARD

        game.draw(screen, font)
        
    elif game_state == STATE_GAME_OVER:
        draw_game_over_screen(screen, font, big_font)

    elif game_state == STATE_CARD_REWARD:
        draw_card_reward_screen(screen, font, big_font)

    elif game_state == STATE_AUGMENT_REWARD:
        draw_augment_reward_screen(
            screen,
            font,
            big_font,
            augment_pick_count,
            game.augment_choices
        )
        

    pygame.display.flip()

pygame.quit()