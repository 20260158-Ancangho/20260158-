# units.py

import math
import random
import pygame
import os

GAME_INSTANCE = None

from settings import *
from effects import FloatingText, MuzzleFlash


_next_squad_id = 1

def get_next_squad_id():
    global _next_squad_id
    value = _next_squad_id
    _next_squad_id += 1
    return value


class Unit:
    def __init__(self, x, y, side, card_data, squad_id=None, member_index=0):
        self.card = card_data
        self.name = card_data["name"]
        self.side = side
        self.unit_type = card_data.get("unit_type", TYPE_INFANTRY)

        # 기본 크기
        size = INFANTRY_SIZE

        # 전차면 크게
        if self.unit_type == TYPE_TANK:
            size = 36

        self.rect = pygame.Rect(x, y, size, size)
        
        self.x = float(x)
        self.y = float(y)

        self.squad_id = squad_id
        self.member_index = member_index
        self.icon = card_data.get("icon", "?")
        
        # 이 병사가 현재 수류탄 담당인지 여부
        self.is_grenadier = (
            self.member_index ==
            self.card.get("grenadier_index", -1)
        )
        
        self.locked_target = None
        
        # 어느 라인에서 소환됐는지 기록
        # left / right / center 중 하나
        self.lane = card_data.get("lane", "center")

        self.max_hp = card_data["hp"]
        self.hp = self.max_hp
        
        self.ignore_center_collision_until = 0

        self.damage_table = card_data["damage"].copy()
        self.attack_delay = card_data["attack_delay"]
        self.attack_range = card_data["attack_range"]
        self.splash_radius = card_data.get("splash_radius", 0)

        self.speed = card_data["speed"]
        self.base_speed = card_data["speed"]

        self.last_attack = 0
        
        self.attack_animation_end = 0
        
        self.frame_index = 0
        self.last_frame_time = 0
        self.sprite_frames = {}
        self.direction = "up_right"

        self.abilities = card_data.get("abilities", []).copy()

        self.morale = 100
        self.suppressed_timer = 0

        self.is_hidden = "위장" in self.abilities
        self.is_suicide = "자폭" in self.abilities
        self.banzai_active = False

        self.is_ranged_infantry = card_data.get("is_ranged_infantry", False)
        self.converted_to_melee = False
        
        # 콜인 진입 상태
        self.is_calling_in = False
        self.call_in_target = None
        
        # -----------------------------
        # 장교 스프라이트 애니메이션 기본값
        # 모든 유닛이 일단 가지고 있게 해두면 오류 방지 가능
        # -----------------------------

        self.frame_index = 0
        self.last_frame_time = 0
        self.sprite_frames = {}

        if self.name == "장교":
            self.load_officer_up_sprites()
            
        if self.name == "일본군 보병":
            self.load_infantry_up_sprites()
        
        self.animation_state = "idle"
        
        # 자전거 보병 전용 상태
        self.is_on_bicycle = "자전거" in self.abilities
        self.dismounting = False
        self.dismount_start_time = 0

        if self.is_on_bicycle:
            self.speed = self.card.get("bicycle_speed", SPEED_FAST)

        # 보조무기 수류탄
        self.last_grenade_time = 0
        
        # 현재 바라보는 방향
        self.direction = "up_right"
        
        self.attack_animation_end = 0
        
        self.animation_state = "attack"

        self.attack_animation_end = (
            pygame.time.get_ticks() + 1200
        )
        
        self.member_index = member_index
        
        self.attack_delay_multiplier = 1.0

        if "member_weapons" in card_data:
            weapon_data = card_data["member_weapons"][self.member_index]

            self.weapon = weapon_data["weapon"]
            self.damage_table = weapon_data["damage"].copy()
            self.attack_delay = weapon_data["attack_delay"]
            self.attack_range = weapon_data["attack_range"]
            self.move_fire = weapon_data.get("move_fire", False)
            
        self.deploying = False
        self.deploy_start_time = 0
        self.deploy_time = self.card.get("deploy_time", 0)
        self.is_deployed = False
        
        self.last_dx = 0
        self.last_dy = 1
        
        self.last_target_seen_time = 0
        
        self.suppressed = False
        self.morale_boosted = False
        self.attack_delay_multiplier = 1.0
        
        self.mg_hit_count = 0
        self.last_mg_hit_time = 0
        
        self.morale_immunity = False
        self.attack_buff = 1.0
        
        self.surprised_timer = 0
        self.has_used_surprise_attack = False
        
        self.temp_abilities = []
        
        self.damage_reduction_buff = False
        self.attack_buff = 1.0
        
        self.army_academy_training = False
    
    
    def load_officer_up_sprites(self):
        self.sprite_frames = {}

        load_targets = {

            # -----------------------------
            # 위쪽
            # -----------------------------

            "up": {
                "base": os.path.join(
                    "assets",
                    "officer_up_sprites"
                ),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack": "attack",
                }
            },

            # -----------------------------
            # 오른쪽 위 대각선
            # -----------------------------

            "up_right": {
                "base": os.path.join(
                    "assets",
                    "officer_up_right_sprites"
               ),
                "folders": {
                    "idle": "idle_up_right",
                    "move": "move_up_right",
                    "charge": "charge_up_right",
                }
            },
            
            "right": {
                "base": os.path.join("assets", "officer_right_sprites"),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack": "attack",
                }
            },
            
            "down_right": {
                "base": os.path.join(
                    "assets",
                    "officer_down_right_sprites"
                ),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack" : "attack",
                }
            },

            # -----------------------------
            # 아래쪽
            # -----------------------------

            "down": {
                "base": os.path.join(
                    "assets",
                    "officer_down_sprites"
                ),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack" : "attack",
                }
            }
        }

        for direction, info in load_targets.items():
            self.sprite_frames[direction] = {}

            for state, folder_name in info["folders"].items():
                folder = os.path.join(info["base"], folder_name)

                frames = []

                if not os.path.exists(folder):
                    print("장교 스프라이트 폴더 없음:", folder)
                    self.sprite_frames[direction][state] = []
                    continue

                files = sorted([
                    f for f in os.listdir(folder)
                    if f.endswith(".png")
                ])

                for filename in files:
                    path = os.path.join(folder, filename)

                    img = pygame.image.load(path).convert_alpha()
                    img = pygame.transform.smoothscale(img, (22, 30))
                    frames.append(img)

                self.sprite_frames[direction][state] = frames
    
    def load_infantry_up_sprites(self):
        self.sprite_frames = {}

        load_targets = {
            "up": {
                "base": os.path.join("assets", "infantry_up_sprites"),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack": "attack",
                }
            },

            "up_right": {
                "base": os.path.join("assets", "infantry_up_right_sprites"),
                "folders": {
                    "idle": "idle_up_right",
                    "move": "move_up_right",
                    "charge": "charge_up_right",
                    "attack": "attack_up_right",
                }
            },
            
            "right": {
                "base": os.path.join("assets", "infantry_right_sprites"),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack": "attack",
                }
            },

            "down_right": {
                "base": os.path.join("assets", "infantry_down_right_sprites"),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack": "attack",
                }
            },
            
            "down": {
                "base": os.path.join("assets", "infantry_down_sprites"),
                "folders": {
                    "idle": "idle",
                    "move": "move",
                    "charge": "charge",
                    "attack": "attack",
                }
            },
        }

        for direction, info in load_targets.items():
            self.sprite_frames[direction] = {}

            for state, folder_name in info["folders"].items():
                folder = os.path.join(info["base"], folder_name)

                frames = []

                if not os.path.exists(folder):
                    self.sprite_frames[direction][state] = []
                    continue

                files = sorted([
                    f for f in os.listdir(folder)
                    if f.endswith(".png")
                ])

                for filename in files:
                    path = os.path.join(folder, filename)
                    img = pygame.image.load(path).convert_alpha()
                    img = pygame.transform.smoothscale(img, (26, 34))
                    frames.append(img)

                self.sprite_frames[direction][state] = frames
                
            
    def draw_officer_sprite(self, screen, font, squad_totals=None, drawn_squads=None):
        # [CHECK] 장교 스프라이트 draw 함수 진입 확인
        # print("장교 draw 진입:", self.animation_state, self.direction)

        state = "idle"

        if self.animation_state == "attack":
            state = "attack"
        elif "돌격" in self.abilities and self.speed >= SPEED_NORMAL:
            state = "charge"
        elif self.animation_state == "move":
            state = "move"

        direction = self.direction
        flip_x = False

        # [CHECK] 공격 중 방향 보정 확인
        # print("공격 방향:", self.last_dx, self.last_dy)

        if self.animation_state == "attack":
            if self.last_dx > 0.4 and abs(self.last_dy) < 0.4:
                direction = "down_right"

            elif self.last_dx < -0.4 and abs(self.last_dy) < 0.4:
                direction = "right"
                flip_x = True
                
            elif self.last_dx > 0.4 and abs(self.last_dy) < 0.4:
                direction = "right"

            elif self.last_dy > 0.4 and abs(self.last_dx) < 0.4:
                direction = "down"

            elif self.last_dy < -0.4 and abs(self.last_dx) < 0.4:
                direction = "up"

        if direction == "up_left":
            direction = "up_right"
            flip_x = True

        elif direction == "down_left":
            direction = "down"
            flip_x = True

        elif direction == "down_right":
            direction = "down_right"

        elif direction == "left":
            direction = "right"
            flip_x = True

        elif direction not in ["up", "up_right", "down", "right", "down_right"]:
            direction = "up"

        if direction not in self.sprite_frames:
            # [CHECK] 해당 방향 스프라이트 없음
            print("스프라이트 방향 없음:", direction)
            direction = "up"

        frames = self.sprite_frames.get(direction, {}).get(state, [])

        if len(frames) == 0:
            # [CHECK] 해당 상태 프레임 없음
            print("프레임 없음:", direction, state)

            pygame.draw.rect(screen, BLUE if self.side == PLAYER else RED, self.rect)
            pygame.draw.rect(screen, WHITE, self.rect, 1)
            return

        now = pygame.time.get_ticks()

        if now - self.last_frame_time > 90:
            self.last_frame_time = now
            self.frame_index = (self.frame_index + 1) % len(frames)

        frame = frames[self.frame_index % len(frames)]

        if flip_x:
            frame = pygame.transform.flip(frame, True, False)

        rect = frame.get_rect(center=self.rect.center)
        screen.blit(frame, rect)
                

    def draw(self, screen, font, squad_totals=None, drawn_squads=None):
        
        if self.name in ["장교", "일본군 보병"] and self.sprite_frames:
            self.draw_officer_sprite(
                screen,
                font,
                squad_totals,
                drawn_squads
            )
            return

        color = BLUE if self.side == PLAYER else RED

        if self.is_hidden:
            color = PURPLE
            
        if self.is_on_bicycle:
            color = (80, 200, 220)

        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, BLACK, self.rect, 1)

        if self.suppressed_timer > 0:
            img = font.render("!", True, ORANGE)
            screen.blit(img, (self.rect.x + 2, self.rect.y - 42))
            
            
    
    def draw_health_bar(self, screen, font, squad_totals=None, drawn_squads=None):
        if squad_totals is None or drawn_squads is None:
            return

        if self.squad_id is None:
            return

        if self.squad_id in drawn_squads:
            return

        drawn_squads.add(self.squad_id)

        total_hp, total_max_hp = squad_totals[self.squad_id]

        bar_width = 38
        bar_height = 5

        bar_x = self.rect.centerx - bar_width // 2
        bar_y = self.rect.y - 12

        hp_ratio = max(0, total_hp / total_max_hp)

        pygame.draw.rect(screen, BLACK, (bar_x, bar_y, bar_width, bar_height))
        pygame.draw.rect(
            screen,
            BLUE if self.side == PLAYER else RED,
            (bar_x, bar_y, int(bar_width * hp_ratio), bar_height)
        )
        pygame.draw.rect(screen, WHITE, (bar_x, bar_y, bar_width, bar_height), 1)
        
        # -----------------------------
        # 아이콘
        # -----------------------------
        
        if self.card.get("icon_image"):

            if not hasattr(self, "cached_icon"):
                self.cached_icon = pygame.image.load(
                    self.card["icon_image"]
                ).convert_alpha()

                self.cached_icon = pygame.transform.smoothscale(
                    self.cached_icon,
                    (14, 14)
                )

            screen.blit(
                self.cached_icon,
                (bar_x + bar_width + 4, bar_y - 4)
            )
            
        if self.deploying:
            now = pygame.time.get_ticks()
            if (
                self.deploying
                and self.deploy_time > 0
                and not self.is_calling_in
            ):
                now = pygame.time.get_ticks()
                progress = (now - self.deploy_start_time) / self.deploy_time
                self.draw_action_bar(screen, progress)
                
        status_y = bar_y - 10
        
        # -----------------------------
        # 버프 아이콘 표시
        # -----------------------------
        buff_x = bar_x
        buff_y = bar_y - 24
        icon_gap = 16

        buff_icons = []

        # 피해 감소 = 방패
        if self.damage_reduction_buff:
            buff_icons.append(("S", (120, 180, 255)))

        # 공격력 증가 = 총
        if self.attack_buff > 1.0:
            buff_icons.append(("G", (255, 220, 120)))

        has_banzai_buff = (
            self.banzai_active
            or "반자이 돌격" in getattr(self, "temp_abilities", [])
        )

        if has_banzai_buff:
            buff_icons.append(("B", (255, 120, 120)))

        for i, (symbol, color) in enumerate(buff_icons):
            text = font.render(symbol, True, color)
            screen.blit(text, (buff_x + i * icon_gap, buff_y))
        
        if self.suppressed:

            pygame.draw.rect(
                screen,
                (170, 40, 40),
                (bar_x, status_y, 42, 8)
            )

            text = font.render(
                "사기 저하",
                True,
                (255, 120, 120)
            )

            screen.blit(
                text,
                (bar_x + 46, status_y - 5)
            )
            
        if self.morale_boosted:

            pygame.draw.rect(
                screen,
                (40, 170, 70),
                (bar_x, status_y, 42, 8)
            )

            text = font.render(
                "사기 증가",
                True,
                (120, 255, 160)
            )

            screen.blit(
                text,
                (bar_x + 46, status_y - 5)
            )
            

    def update(self, now, units, buildings, floating_texts, effects):

        if self.hp <= 0:
            return
        
        if "해군 정신" in self.abilities:
            self.morale_boosted = True
            
        if "야마토 정신" in self.abilities or "야마토 정신" in self.temp_abilities:
            self.suppressed = False
            self.suppressed_timer = 0

        if self.is_calling_in:
            self.move_to_call_in_target()
            
            # 콜인 중에도 서로 밀어냄
            self.resolve_unit_collision(units)

            if not self.card.get("center_spawn_only", False):
                self.prevent_center_building_crossing()

            return

        self.animation_state = "idle"
        
        self.attack_buff = 1.0
        self.temp_abilities = []

        self.update_special_state(units)
        self.update_officer_aura(units)
        
        if self.suppressed_timer > 0:
            self.suppressed_timer -= 1
            self.suppressed = True
        else:
            self.suppressed = False
            
            
        # 사기 증가 상태면 사기 저하 무효
        if self.morale_boosted:   
            self.suppressed = False
            self.suppressed_timer = 0
            
        speed_multiplier = 1.0
        attack_delay_multiplier = 1.0

        if self.morale_boosted:
            speed_multiplier = 1.2
            attack_delay_multiplier = 0.8

        elif self.suppressed:
            speed_multiplier = 0.2
            attack_delay_multiplier = 1.5
            
        # -----------------------------
        # 갑작스러운 공격 디버프
        # -----------------------------
        if self.surprised_timer > 0:
            self.surprised_timer -= 1
            attack_delay_multiplier *= 1.5
            
        self.speed = self.base_speed * speed_multiplier
        self.attack_delay_multiplier = attack_delay_multiplier

        # -----------------------------
        # 타겟 결정
        # -----------------------------
        target = self.get_valid_locked_target()

        if target is None:
            target = self.find_target(units, buildings)
            self.locked_target = target

        # 이동 중이면 중간에 나타난 적을 새 타겟으로 잡음
        is_attacking_now = False

        if target is not None and target.hp > 0:
            dist_to_target = self.distance_to(target)
            is_attacking_now = dist_to_target <= self.attack_range

        if not is_attacking_now:
            blocking_enemy = self.find_blocking_enemy(units)

            if blocking_enemy is not None:
                target = blocking_enemy
                self.locked_target = blocking_enemy

        if target is None or target.hp <= 0:
            self.locked_target = None
            return

        dist = self.distance_to(target)


        # -----------------------------
        # 중기관총 거치 처리
        # -----------------------------
        if self.card.get("machinegun", False):

            target_is_enemy_unit = (
                target is not None
                and hasattr(target, "side")
                and target.side != self.side
                and target.hp > 0
                and not getattr(target, "is_hidden", False)
                and getattr(target, "unit_type", TYPE_INFANTRY) == TYPE_INFANTRY
            )
            
            near_enemy_unit = None

            for unit in units:
                if unit.side == self.side:
                    continue

                if unit.hp <= 0:
                    continue

                if getattr(unit, "is_hidden", False):
                    continue

                if getattr(unit, "unit_type", TYPE_INFANTRY) != TYPE_INFANTRY:
                    continue

                if self.distance_to(unit) <= self.attack_range:
                    near_enemy_unit = unit
                    break

            if near_enemy_unit is not None:
                target = near_enemy_unit
                self.locked_target = near_enemy_unit
                dist = self.distance_to(target)
                target_is_enemy_unit = True

            if target_is_enemy_unit and dist <= self.attack_range:
                self.last_target_seen_time = now

            if self.deploying:
                if now - self.deploy_start_time >= self.deploy_time:
                    self.deploying = False
                    self.is_deployed = True
                    self.last_target_seen_time = now
                return

            if self.is_deployed and not (target_is_enemy_unit and dist <= self.attack_range):
                if now - self.last_target_seen_time >= 1000:
                    self.is_deployed = False
                    self.deploying = False
                    return

            if (
                target_is_enemy_unit
                and dist <= self.attack_range
                and not self.is_deployed
                and not self.deploying
                and now >= self.deploy_block_until
            ):
                self.deploying = True
                self.deploy_start_time = now
                self.animation_state = "idle"
                return

        # -----------------------------
        # 자전거 하차 처리
        # -----------------------------
        if self.is_on_bicycle:

            if dist > self.attack_range:
                self.speed = self.card.get("bicycle_speed", SPEED_FAST)
                self.move_toward(target)
                self.resolve_unit_collision(units)
                self.prevent_center_building_crossing()
                return

            if not self.dismounting:
                self.dismounting = True
                self.dismount_start_time = now
                self.speed = 0
                return

            if now - self.dismount_start_time < BICYCLE_DISMOUNT_DELAY:
                return

            self.is_on_bicycle = False
            self.dismounting = False
            self.speed = self.base_speed

        # -----------------------------
        # 돌격 / 반자이 속도 처리
        # -----------------------------
        if "돌격" in self.abilities or self.banzai_active:
            if dist <= 80:
                self.speed = SPEED_NORMAL
            else:
                self.speed = self.base_speed

        preferred_range = self.card.get("preferred_range", self.attack_range)

        # -----------------------------
        # 공격
        # -----------------------------
        if dist <= self.attack_range and dist <= preferred_range + 5:

            self.animation_state = "attack"
            self.attack_animation_end = now + self.attack_delay

            self.attack(target, now, units, buildings, floating_texts, effects)

            self.resolve_unit_collision(units)
            self.prevent_center_building_crossing()

            return

        # -----------------------------
        # 이동
        # -----------------------------
        self.move_toward(target)
        self.resolve_unit_collision(units)
        self.prevent_center_building_crossing()
                

    def update_special_state(self, units):
        # -----------------------------
        # 일본군 보병: 반자이 돌격
        # 개체 체력이 아니라 분대 총 체력 기준
        # -----------------------------

        if "반자이 돌격" not in self.abilities:
            return
        
        if (
            "inhuman_ideology" in self.card.get("active_augments", [])
            and "반자이 돌격" in self.abilities
        ):
            return

        if self.squad_id is None:
            return

        squad_hp = 0
        squad_max_hp = self.card.get(
            "squad_max_hp",
            self.card["hp"] * self.card["count"]
        )

        for unit in units:
            if unit.squad_id == self.squad_id:
                squad_hp += max(0, unit.hp)

        # 분대 총 체력이 50% 이하가 되면 분대 전체 반자이 발동
        if squad_hp <= squad_max_hp * 0.5:
            self.card["banzai_active"] = True

        if self.card.get("banzai_active", False) and not self.banzai_active:
            self.banzai_active = True

            self.convert_to_melee(
                self.card["bayonet_damage"],
                self.card["bayonet_attack_delay"],
                self.card["bayonet_range"]
            )
            
                    
    def update_officer_aura(self, units):
        # 장교 특수 능력:
        # 주변 원거리 보병을 근접 보병으로 바꾸고,
        # 주변 보병에게 돌격 능력을 부여함.
        if self.name != "장교":
            return

        for unit in units:
            if unit.side != self.side:
                continue

            if unit.hp <= 0:
                continue

            if unit is self:
                continue

            if unit.unit_type != TYPE_INFANTRY:
                continue

            if self.distance_to(unit) > OFFICER_AURA_RANGE:
                continue

            if "돌격" not in unit.abilities:
                unit.abilities.append("돌격")

            if unit.is_ranged_infantry and not unit.converted_to_melee:
                # 소총 계열은 총검, 연발 무기 계열은 나이프라는 설정.
                # 현재 코드는 둘 다 근접 보병화로 처리.
                melee_damage = {
                    TYPE_INFANTRY: max(unit.damage_table.get(TYPE_INFANTRY, 0), 160),
                    TYPE_VEHICLE: max(unit.damage_table.get(TYPE_VEHICLE, 0), 20),
                    TYPE_TANK: max(unit.damage_table.get(TYPE_TANK, 0), 3),
                    TYPE_BUILDING: max(unit.damage_table.get(TYPE_BUILDING, 0), 35),
                }

                unit.convert_to_melee(
                    melee_damage,
                    1000,
                    20
                )
                
            if "encouragement" in self.card.get("active_augments", []):
                if "야마토 정신" not in unit.temp_abilities:
                    unit.temp_abilities.append("야마토 정신")
                
        # 팔로군 정치장교: 독려 / 지휘
        if self.name == "팔로군 정치장교":
            for unit in units:
                if unit.side != self.side:
                    continue
                if unit.hp <= 0:
                    continue
                if unit.unit_type != TYPE_INFANTRY:
                    continue
                if self.distance_to(unit) > 90:
                    continue

                # 독려: 사기 저하 면역
                if "독려" in self.abilities:
                    unit.suppressed = False
                    unit.suppressed_timer = 0
                    unit.morale_immunity = True

                # 지휘: 공격력 10% 증가
                if "지휘" in self.abilities:
                    unit.attack_buff = 1.1
                

    def convert_to_melee(self, new_damage, new_attack_delay, new_attack_range):
        self.damage_table = new_damage.copy()
        self.attack_delay = new_attack_delay
        self.attack_range = new_attack_range
        self.converted_to_melee = True
        self.is_ranged_infantry = False
        

    def find_target(self, units, buildings):
        targets = []

        for unit in units:
            if unit.side != self.side and unit.hp > 0:
                if getattr(unit, "is_hidden", False):
                    continue

                # 다른 라인 유닛은 기본적으로 무시하지만,
                # 사거리 안에 들어온 가까운 적은 타겟으로 인정
                if getattr(unit, "lane", None) != self.lane:
                    if self.distance_to(unit) > self.attack_range:
                        continue


                target_type = getattr(unit, "unit_type", TYPE_INFANTRY)
                if self.damage_table.get(target_type, 0) <= 0:
                    continue
                
                # -----------------------------
                # 대전차병은 보병을 공격하지 않음
                # -----------------------------
                if "대전차병" in self.abilities:
                    if target_type == TYPE_INFANTRY:
                        continue

                targets.append(unit)

        for building in buildings:
            if building.side != self.side and building.hp > 0:
                if self.damage_table.get(TYPE_BUILDING, 0) <= 0:
                    continue

                targets.append(building)

        if not targets:
            return None

        priority = self.card.get("target_priority")

        if priority:
            targets.sort(key=lambda t: (
                priority.index(getattr(t, "unit_type", TYPE_BUILDING))
                if getattr(t, "unit_type", TYPE_BUILDING) in priority else 99,
                self.distance_to(t)
            ))
        else:
            targets.sort(key=lambda t: self.distance_to(t))

        return targets[0]
    

    def move_forward(self):
        move_speed = self.speed

        if self.suppressed_timer > 0:
            move_speed *= 0.45

        if self.side == PLAYER:
            self.y -= move_speed
            self.last_dx = 0
            self.last_dy = -1
        else:
            self.y += move_speed
            self.last_dx = 0
            self.last_dy = 1

        if not (
            self.animation_state == "attack"
            and pygame.time.get_ticks() < self.attack_animation_end
        ):
            self.animation_state = "move"

        self.rect.x = int(self.x)
        self.rect.y = int(self.y)
        

    def move_toward(self, target):
        move_speed = self.speed

        if self.suppressed_timer > 0:
            move_speed *= 0.45
        
        dx = target.rect.centerx - self.rect.centerx
        dy = target.rect.centery - self.rect.centery
        
        dist = max(1, math.hypot(dx, dy))
        
        self.update_direction(
            target.rect.centerx,
            target.rect.centery
        )

        self.last_dx = dx / dist
        self.last_dy = dy / dist

        self.x += self.last_dx * move_speed
        self.y += self.last_dy * move_speed

        if not (
            self.animation_state == "attack"
            and pygame.time.get_ticks() < self.attack_animation_end
        ):
            self.animation_state = "move"

        self.rect.x = int(self.x)
        self.rect.y = int(self.y)
        
        if self.card.get("machinegun", False):
            self.is_deployed = False
            self.deploying = False
            
    def resolve_unit_collision(self, units):
        if self.is_calling_in:
            return

        checked = 0

        for other in units:
            if other is self:
                continue

            if other.hp <= 0:
                continue

            # 너무 멀면 검사 안 함
            dx = self.rect.centerx - other.rect.centerx
            dy = self.rect.centery - other.rect.centery

            if abs(dx) > 22 or abs(dy) > 22:
                continue

            dist = max(1, math.hypot(dx, dy))

            if dist < 14:
                push = (14 - dist) * 0.12

                self.x += dx / dist * push
                self.y += dy / dist * push
                self.rect.x = int(self.x)
                self.rect.y = int(self.y)

            checked += 1
            if checked >= 4:
                break
        

    def attack(self, target, now, units, buildings, floating_texts, effects):

        if self.is_calling_in:
            return

        if self.card.get("machinegun", False) and not self.is_deployed:
            return

        # 공격 쿨타임 확인: 사기 상태 보정 포함
        effective_attack_delay = self.attack_delay * self.attack_delay_multiplier

        if now - self.last_attack < effective_attack_delay:
            return

        self.last_attack = now

        self.animation_state = "attack"
        self.attack_animation_end = now + effective_attack_delay
        self.frame_index = 0

        self.current_frame = 0
        self.last_frame_update = pygame.time.get_ticks()

        dx = target.rect.centerx - self.rect.centerx
        dy = target.rect.centery - self.rect.centery
        dist = max(1, math.hypot(dx, dy))

        self.last_dx = dx / dist
        self.last_dy = dy / dist

        self.update_direction(
            target.rect.centerx,
            target.rect.centery
        )

        if self.is_hidden:
            self.is_hidden = False
            

        target_type = getattr(target, "unit_type", TYPE_BUILDING)
        damage = self.damage_table.get(target_type, 0)
        damage = int(damage * self.attack_buff)

        if damage <= 0:
            return
        
        if (
            "inhuman_ideology" in self.card.get("active_augments", [])
            and "반자이 돌격" in self.abilities
        ):
            damage = int(damage * 1.2)
            
        if (
            getattr(self, "army_academy_training", False)
            and self.attack_range <= 25
        ):
            damage = int(damage * 1.2)

        if self.splash_radius > 0:
            self.area_damage(target, damage, units, buildings, floating_texts)
        else:
            target.take_damage(damage, floating_texts)
            
        
        if "갑작스러운 공격" in self.abilities and not self.has_used_surprise_attack:
            if hasattr(target, "unit_type"):
                target.surprised_timer = 360
                self.has_used_surprise_attack = True


        # -----------------------------
        # 중기관총 사기 저하 누적 시스템
        # -----------------------------
        if self.card.get("morale_break", False):

            squad_units = []

            for unit in units:

                if unit.side != target.side:
                    continue

                if unit.squad_id != target.squad_id:
                    continue

                squad_units.append(unit)

            if len(squad_units) > 0:

                squad_leader = squad_units[0]

                # 오래 지나면 초기화
                if now - squad_leader.last_mg_hit_time > 2500:
                    squad_leader.mg_hit_count = 0

                squad_leader.last_mg_hit_time = now
                squad_leader.mg_hit_count += 1

                # 3회 누적
                if squad_leader.mg_hit_count >= 3:

                    squad_leader.mg_hit_count = 0

                    # -----------------------------
                    # 대상 분대 전체 사기 저하
                    # -----------------------------
                    for unit in squad_units:
                        
                        if unit.unit_type != TYPE_INFANTRY:
                            continue

                        if "야마토 정신" in unit.abilities:
                            continue

                        if unit.morale_boosted:
                            continue

                        unit.suppressed = True
                        unit.suppressed_timer = 180

                    # -----------------------------
                    # 주변 아군도 사기 저하
                    # -----------------------------
                    for unit in units:

                        if unit.side != target.side:
                            continue
                        
                        if unit.unit_type != TYPE_INFANTRY:
                            continue

                        if "야마토 정신" in unit.abilities:
                            continue

                        if unit.hp <= 0:
                            continue

                        if unit.morale_boosted:
                            continue

                        dist = math.hypot(
                            unit.rect.centerx - target.rect.centerx,
                            unit.rect.centery - target.rect.centery
                        )

                        if dist <= 90:
                            unit.suppressed = True
                            unit.suppressed_timer = 120
                            
        flash = MuzzleFlash(
            self.rect.centerx,
            self.rect.centery,
            self.last_dx,
            self.last_dy,
            14 if self.unit_type == TYPE_TANK else 7
        )

        effects.append(flash)

        if "수류탄" in self.abilities:
            self.try_throw_grenade(target, now, units, buildings, floating_texts)

        if target.hp <= 0 and target is self.locked_target:
            self.locked_target = None

        if self.is_suicide:
            self.hp = 0
            
            
    def draw_action_bar(self, screen, progress):
        bar_w = 34
        bar_h = 5

        bar_x = self.rect.centerx - bar_w // 2
        bar_y = self.rect.y - 22

        progress = max(0, min(1, progress))

        pygame.draw.rect(screen, BLACK, (bar_x, bar_y, bar_w, bar_h))
        pygame.draw.rect(
            screen,
            WHITE,
            (bar_x, bar_y, int(bar_w * progress), bar_h)
        )
        pygame.draw.rect(screen, WHITE, (bar_x, bar_y, bar_w, bar_h), 1)
        

    def area_damage(self, target, damage, units, buildings, floating_texts):
        tx = target.rect.centerx
        ty = target.rect.centery

        for unit in units:
            if unit.side != self.side and unit.hp > 0:
                d = math.hypot(unit.rect.centerx - tx, unit.rect.centery - ty)
                if d <= self.splash_radius:
                    unit_type = getattr(unit, "unit_type", TYPE_INFANTRY)
                    final_damage = self.damage_table.get(unit_type, damage)
                    unit.take_damage(final_damage, floating_texts)

        for building in buildings:
            if building.side != self.side and building.hp > 0:
                d = math.hypot(building.rect.centerx - tx, building.rect.centery - ty)
                if d <= self.splash_radius:
                    final_damage = self.damage_table.get(TYPE_BUILDING, damage)
                    building.take_damage(final_damage, floating_texts)
                    
                    
    def try_throw_grenade(self, target, now, units, buildings, floating_texts):
        
        # -----------------------------
        # 현재 수류탄 담당 병사만 사용 가능
        # -----------------------------

        grenadier_index = self.card.get("grenadier_index", 0)

        if self.member_index != grenadier_index:
            return
        
        # 수류탄 쿨타임 확인
        grenade_delay = self.card.get("grenade_delay", 10000)

        if now - self.last_grenade_time < grenade_delay:
            return

        # 수류탄 사거리 확인
        grenade_range = self.card.get("grenade_range", 60)

        if self.distance_to(target) > grenade_range:
            return

        self.last_grenade_time = now

        grenade_damage_table = self.card.get("grenade_damage", {})
        splash_radius = self.card.get("grenade_splash_radius", 45)

        tx = target.rect.centerx
        ty = target.rect.centery

        # 적 유닛에게 광역 피해
        for unit in units:
            if unit.side != self.side and unit.hp > 0:
                d = math.hypot(unit.rect.centerx - tx, unit.rect.centery - ty)

                if d <= splash_radius:
                    unit_type = getattr(unit, "unit_type", TYPE_INFANTRY)
                    damage = grenade_damage_table.get(unit_type, 0)

                    if damage > 0:
                        unit.take_damage(damage, floating_texts)

        # 적 건물에게 광역 피해
        for building in buildings:
            if building.side != self.side and building.hp > 0:
                d = math.hypot(building.rect.centerx - tx, building.rect.centery - ty)

                if d <= splash_radius:
                    damage = grenade_damage_table.get(TYPE_BUILDING, 0)

                    if damage > 0:
                        building.take_damage(damage, floating_texts)

        floating_texts.append(
            FloatingText("수류탄!", self.rect.centerx, self.rect.y - 20, ORANGE)
        )

    def reduce_morale(self, amount):
        if "야마토 정신" in self.abilities:
            return

        self.morale -= amount

        if self.morale <= 0:
            self.morale = 45
            self.suppressed_timer = 120
            

    def take_damage(self, amount, floating_texts):
        
        # -----------------------------
        # 죽음을 무릎 쓴 정신력
        # -----------------------------
        has_yamato = (
            "야마토 정신" in self.abilities
            or "야마토 정신" in getattr(self, "temp_abilities", [])
        )

        if (
            hasattr(self, "active_augments")
            and "death_defying_spirit" in self.active_augments
            and has_yamato
        ):
            amount = int(amount * 0.9)
            self.damage_reduction_buff = True
        else:
            self.damage_reduction_buff = False
            
        self.hp -= amount

        # 병사 하나가 죽을 정도로 체력이 낮아지면
        # 분대 인원 감소 연출

        if self.hp <= 0:
            self.hp = 0

        floating_texts.append(
            FloatingText(
                f"-{int(amount)}",
                self.rect.centerx,
                self.rect.y,
                WHITE
            )
        )
        
        # -----------------------------
        # 수류탄 담당 병사가 죽으면
        # 다른 병사에게 역할 승계
        # -----------------------------

        if self.hp <= 0:

            if self.is_grenadier:
                self.assign_new_grenadier()
                
        if "banzai_defense" in self.card.get("active_augments", []):
            if "돌격" in self.abilities or "반자이 돌격" in self.abilities:
                damage *= 0.9
                
                
    def assign_new_grenadier(self):

        # 이미 다른 병사가 지정됐으면 종료
        if self.card.get("grenadier_index") != self.member_index:
            return

        # 다음 병사 번호 지정
        next_index = self.member_index + 1

        # 분대 인원 범위 안이면 승계
        if next_index < self.card["count"]:

            self.card["grenadier_index"] = next_index

    def distance_to(self, target):
        return math.hypot(
            self.rect.centerx - target.rect.centerx,
            self.rect.centery - target.rect.centery
        )
    
    def prevent_center_building_crossing(self):
        
        if pygame.time.get_ticks() < self.ignore_center_collision_until:
            return
        # 중앙 건물 충돌 영역
        center_block = pygame.Rect(410, 220, 180, 220)

        if not self.rect.colliderect(center_block):
            return

        # 왼쪽 라인 유닛은 왼쪽으로 밀어냄
        if self.lane == "left":
            self.x = center_block.left - self.rect.width - 2

        # 오른쪽 라인 유닛은 오른쪽으로 밀어냄
        elif self.lane == "right":
            self.x = center_block.right + 2

        self.rect.x = int(self.x)
        self.rect.y = int(self.y)
        
        
    def move_to_call_in_target(self):
        if self.call_in_target is None:
            self.is_calling_in = False
            return

        tx, ty = self.call_in_target

        dx = tx - self.rect.centerx
        dy = ty - self.rect.centery
        dist = max(1, math.hypot(dx, dy))

        move_speed = max(self.speed, SPEED_SLOW)

        self.x += dx / dist * move_speed
        self.y += dy / dist * move_speed

        self.rect.x = int(self.x)
        self.rect.y = int(self.y)

        self.animation_state = "move"

        if dist < 6:
            self.is_calling_in = False
            self.call_in_target = None
            self.deploy_block_until = pygame.time.get_ticks() + 700

            if self.card.get("center_spawn_only", False):
                self.is_hidden = False
                self.ignore_center_collision_until = pygame.time.get_ticks() + 700
            
        self.update_direction(tx, ty)
        
            
            
    def update_direction(self, target_x, target_y):
        dx = target_x - self.rect.centerx
        dy = target_y - self.rect.centery

        # 너무 작은 좌우 차이는 중앙 이동으로 취급
        deadzone = 18

        if abs(dx) <= deadzone and dy < 0:
            self.direction = "up"

        elif abs(dx) <= deadzone and dy > 0:
            self.direction = "down"

        elif dx > deadzone and dy < 0:
            self.direction = "up_right"

        elif dx < -deadzone and dy < 0:
            self.direction = "up_left"

        elif dx > deadzone and dy > 0:
            self.direction = "down_right"

        elif dx < -deadzone and dy > 0:
            self.direction = "down_left"

        elif dx > deadzone:
            self.direction = "right"

        elif dx < -deadzone:
            self.direction = "left"
            

    def get_valid_locked_target(self):
        if self.locked_target is None:
            return None

        if self.locked_target.hp <= 0:
            self.locked_target = None
            return None

        if self.locked_target.side == self.side:
            self.locked_target = None
            return None

        return self.locked_target
    
    def find_blocking_enemy(self, units):
        # 돌격 중 몸에 가까이 닿은 적이 있으면 그 적을 우선 공격
        block_range = 70

        for unit in units:
            # 은신 유닛은 적이 먼저 타겟팅할 수 없음
            if getattr(unit, "is_hidden", False):
                continue
            
            if unit is self:
                continue

            if unit.side == self.side:
                continue

            if unit.hp <= 0:
                continue

            #if getattr(unit, "lane", None) != self.lane:
                #continue
            
            if "대전차병" in self.abilities:
                if getattr(unit, "unit_type", TYPE_INFANTRY) == TYPE_INFANTRY:
                    continue

            if self.distance_to(unit) <= block_range:
                return unit

        return None


def create_units_from_card(card_data, x, y, side):
    created = []

    card_data = card_data.copy()
    
    # 수류탄 보유 분대는 0번 분대원이 수류탄 담당
    if "수류탄" in card_data.get("abilities", []):
            card_data["grenadier_index"] = 0

    card_data["squad_max_hp"] = (
        card_data["hp"] *
        card_data["count"]
    )
    # -----------------------------
    # 배치 위치에 따른 콜인 시작 위치
    # 후방 진입로: 맵 아래에서 등장
    # 측면 진입로: 맵 옆에서 등장
    # -----------------------------
    
    # -----------------------------
    # 중앙 건물 전용 배치
    # -----------------------------
    if card_data.get("center_spawn_only", False):
        if x < WIDTH // 2:
            card_data["lane"] = "left"
            spawn_x = 382
            exit_dx = -1
        else:
            card_data["lane"] = "right"
            spawn_x = 592
            exit_dx = 1

        CENTER_BUILDING_CENTER_Y = 330

        if y < CENTER_BUILDING_CENTER_Y:
            spawn_y = 250
            exit_dy = -1
        else:
            spawn_y = 394
            exit_dy = 1

        card_data["center_exit_dx"] = exit_dx
        card_data["center_exit_dy"] = exit_dy

    else:
        
        is_rear_spawn = False
        
        if side == ENEMY and card_data.get("enemy_rear_spawn", False):
            is_rear_spawn = True
        else:
            for zone in PLAYER_REAR_ZONES:
                if pygame.Rect(zone).collidepoint(x, y):
                    is_rear_spawn = True
                    break


        #후방진입로
        for zone in PLAYER_REAR_ZONES:
            if pygame.Rect(zone).collidepoint(x, y):
                is_rear_spawn = True
                break

        if x < WIDTH // 2:
            card_data["lane"] = "left"
        else:
            card_data["lane"] = "right"

        if is_rear_spawn:
            spawn_x = x

            if side == PLAYER:
                spawn_y = MAP_BOTTOM + 35
            else:
                spawn_y = - 35

        else:
            if x < WIDTH // 2:
                spawn_x = + 120
            else:
                spawn_x = WIDTH - 120

            spawn_y = y

    squad_id = get_next_squad_id()

    for i in range(card_data["count"]):

        # -----------------------------
        # 중앙 건물 전용 스폰
        # -----------------------------


        if card_data.get("center_spawn_only", False):
            exit_dx = card_data.get("center_exit_dx", 0)
            exit_dy = card_data.get("center_exit_dy", 0)

            target_x = spawn_x + exit_dx * 45 + random.randint(-12, 12)
            target_y = y + random.randint(-8, 8)

        # -----------------------------
        # 일반 스폰
        # -----------------------------
        else:

            target_x = x + random.randint(-22, 22)
            target_y = y + random.randint(-18, 18)

        unit = Unit(
            spawn_x + random.randint(-8, 8),
            spawn_y + random.randint(-12, 12),
            side,
            card_data,
            squad_id=squad_id,
            member_index=i
        )
        
        if (
            "army_academy_training"
            in card_data.get("active_augments", [])
        ):

            # 장교 체력 +30%
            if card_data["id"] == "officer":
                unit.hp = int(unit.hp * 1.3)
                unit.max_hp = int(unit.max_hp * 1.3)

            # 근접 공격력 +20%
            unit.army_academy_training = True


        unit.is_calling_in = True
        unit.call_in_target = (target_x, target_y)

        created.append(unit)

    return created


def create_enemy_infantry():

    data = {
        "name": "미군 일반 보병",
        "icon": "총",
        "cost": 0,
        "unit_type": TYPE_INFANTRY,
        "count": 1,
        "hp": 2500,
        "damage": {
            TYPE_INFANTRY: 15,
            TYPE_VEHICLE: 10,
            TYPE_TANK: 4,
            TYPE_BUILDING: 10,
        },
        "attack_delay": 900,
        "attack_range": 120,
        "splash_radius": 0,
        "speed": 0.8,
        "abilities": [],
        "is_ranged_infantry": True,
    }

    # 분대 최대 체력 저장
    data["squad_max_hp"] = (
        data["hp"] *
        data["count"]
    )

    x, y = random.choice(ENEMY_SPAWN_POINTS)

    # 라인 지정
    if x < WIDTH // 2:
        data["lane"] = "left"
    else:
        data["lane"] = "right"

    return Unit(
        x,
        y,
        ENEMY,
        data,
        squad_id=get_next_squad_id()
    )