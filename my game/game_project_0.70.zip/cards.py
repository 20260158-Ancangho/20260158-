# cards.py

from settings import *

CARD_POOL = [
    {
        "id": "japanese_infantry",
        "name": "일본군 보병",
        "icon_image": "assets/ui/infantry_icon_circle.png",
        "cost": 1,
        "image": "assets/cards/infantry_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 6,
        "hp": 352,
        "damage": {
            TYPE_INFANTRY: 65,
            TYPE_VEHICLE: 42,
            TYPE_TANK: 11,
            TYPE_BUILDING: 35,
        },
        "bayonet_damage": {
            TYPE_INFANTRY: 200,
            TYPE_VEHICLE: 23,
            TYPE_TANK: 3,
            TYPE_BUILDING: 42,
        },
        "attack_delay": 1500,
        "bayonet_attack_delay": 1200,
        "attack_range": 80,
        "bayonet_range": 20,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "is_ranged_infantry": True,
        "abilities": ["반자이 돌격"],
    },

    {
        "id": "suicide_soldier",
        "name": "자폭병",
        "icon_image": "assets/ui/suicide_soldier_icon_circle.png",
        "cost": 3,
        "image": "assets/cards/suicide_soldier_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 1,
        "hp": 1004,
        "damage": {
            TYPE_INFANTRY: 896,
            TYPE_VEHICLE: 960,
            TYPE_TANK: 1026,
            TYPE_BUILDING: 680,
        },
        "attack_delay": 800,
        "attack_range": 20,
        "splash_radius": 90,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "abilities": ["야마토 정신", "돌격", "자폭"],
    },

    {
        "id": "night_raiders",
        "name": "야습대",
        "icon_image": "assets/ui/night_raiders_icon_circle.png",
        "cost": 4,
        "image": "assets/cards/night_raiders_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 4,
        "hp": 674,
        "damage": {
            TYPE_INFANTRY: 42,
            TYPE_VEHICLE: 23,
            TYPE_TANK: 7,
            TYPE_BUILDING: 20,
        },
        "attack_delay": 400,
        "attack_range": 60,
        "preferred_range": 40,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": True,
        "is_ranged_infantry": True,
        "abilities": ["위장", "매복"],
    },

    {
        "id": "lunge_mine_soldier",
        "name": "자돌 폭뢰병",
        "icon_image": "assets/ui/lunge_mine_soldier_icon_circle.png",
        "cost": 2,
        "image": "assets/cards/lunge_mine_soldier_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 3,
        "hp": 460,
        "damage": {
            TYPE_INFANTRY: 460,
            TYPE_VEHICLE: 950,
            TYPE_TANK: 1084,
            TYPE_BUILDING: 530,
        },
        "attack_delay": 500,
        "attack_range": 20,
        "splash_radius": 40,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "target_priority": [TYPE_TANK, TYPE_VEHICLE, TYPE_BUILDING, TYPE_INFANTRY],
        "abilities": ["자폭", "돌격", "대전차병"],
    },

    {
        "id": "officer",
        "name": "장교",
        "icon_image": "assets/ui/officer_icon_circle.png",
        "cost": 3,
        "image": "assets/cards/officer_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 1,
        "hp": 2030,
        "damage": {
            TYPE_INFANTRY: 520,
            TYPE_VEHICLE: 0,
            TYPE_TANK: 0,
            TYPE_BUILDING: 500,
        },
        "attack_delay": 1200,
        "attack_range": 20,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "target_priority": [TYPE_INFANTRY, TYPE_BUILDING],
        "abilities": ["돌격", "근접 전환", "돌격 부여"],
    },
    
    {
        "id": "bicycle_infantry",
        "name": "자전거 보병",
        "icon_image": "assets/ui/bicycle_infantry_icon_circle.png",
        "cost": 5,
        "image": "assets/cards/bicycle_infantry_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 3,
        "hp": 803,
        "damage": {
            TYPE_INFANTRY: 45,
            TYPE_VEHICLE: 25,
            TYPE_TANK: 13,
            TYPE_BUILDING: 35,
        },
        "grenade_damage": {
            TYPE_INFANTRY: 450,
            TYPE_VEHICLE: 340,
            TYPE_TANK: 150,
            TYPE_BUILDING: 375,
        },
        "attack_delay": 500,
        "attack_range": 60,
        "preferred_range": 40,
        "splash_radius": 0,
        "grenade_delay": 10000,
        "grenade_range": 60,
        "grenade_splash_radius": 30,
        "speed": SPEED_SLOW,
        "bicycle_speed": SPEED_FAST,
        "can_flank": False,
        "is_ranged_infantry": True,
        "abilities": ["자전거", "수류탄"],
    },
    
    {
        "id": "AMBUSH_SQUAD_CARD",
        "name": "매복대",
        "icon_image": "assets/ui/AMBUSH_SQUAD_icon_circle.png",
        "cost": 3,
        "image": "assets/cards/AMBUSH_SQUAD_card.png",
        "unit_type": TYPE_INFANTRY,
        "hp": 823,
        "weapon": "소총",
        "damage": {
            TYPE_INFANTRY: 151,
            TYPE_VEHICLE: 73,
            TYPE_TANK: 6,
            TYPE_BUILDING: 82,
        },

        "attack_delay": 1500,
        "attack_range": 100,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "count": 4,

        "abilities": [
            "매복",
            "반자이 돌격",
        ],

        # 중앙 건물 전용 배치
        "center_spawn_only": True,

        # 반자이 총검
        "bayonet_damage": {
            TYPE_INFANTRY: 200,
            TYPE_VEHICLE: 23,
            TYPE_TANK: 3,
            TYPE_BUILDING: 42,
        },
        "bayonet_attack_delay": 1200,
        "bayonet_range": 20,
    },
    {
        "id": "manchukuo_troops",
        "name": "만주군 부대",
        "icon_image": "assets/ui/manchukuo_troops_icon_circle.png",
        "cost": 1,
        "image": "assets/cards/manchukuo_troops_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 10,
        "hp": 84,
        "damage": {
            TYPE_INFANTRY: 39,
            TYPE_VEHICLE: 32,
            TYPE_TANK: 14,
            TYPE_BUILDING: 32,
        },
        "attack_delay": 1500,
        "attack_range": 70,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "abilities": [],
    },
    {
        "id": "type_92_machinegun",
        "name": "92식 중기관총",
        "cost": 4,
        "image": "assets/cards/type_92_machinegun_card.png",
        "unit_type": TYPE_INFANTRY,
        "count": 1,
        "hp": 1432,
        "damage": {
            TYPE_INFANTRY: 62,
            TYPE_VEHICLE: 56,
            TYPE_TANK: 20,
            TYPE_BUILDING: 46,
        },
        "attack_delay": 200,
        "attack_range": 120,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "abilities": ["중기관총", "사기 저하"],
        "machinegun": True,
        "deploy_time": 1200,
        "morale_break": True,
    },
]

STAGE1_ENEMY_CARDS = [

    {
        "id": "nra_infantry",
        "name": "국민 혁명군 보병",
        "cost": 1,
        "hp": 122,
        "count": 8,
        "damage": {
            TYPE_INFANTRY: 27,
            TYPE_VEHICLE: 21,
            TYPE_TANK: 6,
            TYPE_BUILDING: 35,
        },
        "attack_delay": 1500,
        "attack_range": 70,
        "speed": SPEED_SLOW,
        "type": TYPE_INFANTRY,
    },

    {
        "name": "돌격 권총 부대",
        "cost": 2,
        "hp": 322,
        "count": 4,
        "damage": {
            TYPE_INFANTRY: 32,
            TYPE_VEHICLE: 8,
            TYPE_TANK: 4,
            TYPE_BUILDING: 20,
        },
        "attack_delay": 450,
        "attack_range": 50,
        "speed": SPEED_SLOW,
        "type": TYPE_INFANTRY,
        "move_fire": True
    },

    {
        "name": "24식 중기관총 분대",
        "cost": 3,
        "hp": 842,
        "count": 1,
        "damage": {
            TYPE_INFANTRY: 53,
            TYPE_VEHICLE: 42,
            TYPE_TANK: 12,
            TYPE_BUILDING: 30,
        },
        "attack_delay": 200,
        "attack_range": 110,
        "speed": SPEED_SLOW,
        "type": TYPE_INFANTRY,

        "machinegun": True,
        "deploy_time": 1200,
        "morale_break": True
    },

    {
        "name": "독일식 무장 보병 분대",
        "cost": 5,
        "hp": 1050,
        "count": 3,
        #이건 없는 무기임.
        "damage": {
            TYPE_INFANTRY: 70,
            TYPE_VEHICLE: 60,
            TYPE_TANK: 10,
            TYPE_BUILDING: 46,
        },
        "attack_delay": 600,
        "attack_range": 70,
        "member_weapons": [
            {
            "weapon": "MP18",
                "damage": {
                    TYPE_INFANTRY: 62,
                    TYPE_VEHICLE: 22,
                    TYPE_TANK: 8,
                    TYPE_BUILDING: 30,
                },
                "attack_delay": 300,
                "attack_range": 60,
                "move_fire": True,
            },
            {
                "weapon": "ZB26 경기관총",
                "damage": {
                    TYPE_INFANTRY: 70,
                    TYPE_VEHICLE: 60,
                    TYPE_TANK: 10,
                    TYPE_BUILDING: 46,
                },
                "attack_delay": 600,
                "attack_range": 70,
            },
            {
                "weapon": "Kar98k",
                "damage": {
                    TYPE_INFANTRY: 236,
                    TYPE_VEHICLE: 83,
                    TYPE_TANK: 63,
                    TYPE_BUILDING: 72,
                },
                "attack_delay": 1500,
                "attack_range": 80,
            },
        ],
        "speed": SPEED_SLOW,
        "type": TYPE_INFANTRY
    },
]

STAGE2_ENEMY_CARDS = [
    {
        "id": "warlord_infantry",
        "name": "군벌 보병 분대",
        "cost": 1,
        "icon_image": "assets/ui/warlord_infantry_icon_circle.png",
        "unit_type": TYPE_INFANTRY,
        "count": 11,

        "hp": 102,

        "damage": {
            TYPE_INFANTRY: 38,
            TYPE_VEHICLE: 23,
            TYPE_TANK: 7,
            TYPE_BUILDING: 12,
        },

        "attack_delay": 1500,
        "attack_range": 60,

        "speed": SPEED_SLOW,
    },
    
    {
        "id": "eighth_route_army",
        "name": "팔로군",

        "cost": 5,

        "unit_type": TYPE_INFANTRY,
        "count": 5,

        "hp": 532,

        "damage": {
            TYPE_INFANTRY: 26,
            TYPE_VEHICLE: 21,
            TYPE_TANK: 6,
            TYPE_BUILDING: 20,
        },

        "grenade_damage": {
            TYPE_INFANTRY: 432,
            TYPE_VEHICLE: 360,
            TYPE_TANK: 230,
            TYPE_BUILDING: 250,
        },

        "attack_delay": 300,

        "attack_range": 60,
        "preferred_range": 40,

        "grenade_delay": 14000,

        "grenade_range": 60,
        "grenade_splash_radius": 30,

        "speed": SPEED_SLOW,

        "can_flank": True,

        "abilities": [
            "암행",
            "매복",
            "수류탄"
        ]
    },
    
    {
        "id": "anti_japanese_sword_unit",

        "name": "항일 대도 부대",

        "cost": 2,

        "unit_type": TYPE_INFANTRY,
        "count": 6,

        "hp": 304,

        "damage": {
            TYPE_INFANTRY: 180,
            TYPE_VEHICLE: 50,
            TYPE_TANK: 4,
            TYPE_BUILDING: 30,
        },

        "attack_delay": 1200,

        "attack_range": 20,

        "speed": SPEED_SLOW,

        "abilities": []
    },
    
    {
        "id": "eighth_route_political_officer",

        "name": "팔로군 정치장교",

        "cost": 3,

        "unit_type": TYPE_INFANTRY,

        "count": 1,

        "hp": 1530,

        "damage": {
            TYPE_INFANTRY: 130,
            TYPE_VEHICLE: 120,
            TYPE_TANK: 10,
            TYPE_BUILDING: 40,
        },

        "attack_delay": 1500,

        "attack_range": 70,

        "speed": SPEED_SLOW,

        "abilities": [
            "독려",
            "지휘"
        ]
    },
]    

TIGER_CARD = {
    "id": "tiger_tank",
    "name": "티거",
    "unit_type": TYPE_TANK,
    "count": 1,
    "hp": 8600,
    "damage": {
        TYPE_INFANTRY: 664,
        TYPE_VEHICLE: 1819,
        TYPE_TANK: 1900,
        TYPE_BUILDING: 1000,
    },
    "attack_delay": 3500,
    "attack_range": 120,
    "splash_radius": 25,
    "speed": SPEED_SLOW,
}

PARTISAN_CARD = {
    "id": "partisan",
    "name": "빨치산",
    "cost": 0,

    "unit_type": TYPE_INFANTRY,
    "count": 4,
    "hp": 360,

    "damage": {
        TYPE_INFANTRY: 62,
        TYPE_VEHICLE: 32,
        TYPE_TANK: 12,
        TYPE_BUILDING: 25,
    },

    "attack_delay": 300,
    "attack_range": 60,
    "preferred_range": 40,

    "splash_radius": 0,
    "speed": SPEED_SLOW,
    "can_flank": True,

    "abilities": ["암행", "갑작스러운 공격"],
}


def get_card_by_id(card_id):
    card_lists = [
        "PLAYER_CARDS",
        "CARDS",
        "PLAYER_DECK",
        "PLAYER_CARD_POOL",
        "STAGE1_ENEMY_CARDS",
        "STAGE2_ENEMY_CARDS",
    ]

    for list_name in card_lists:
        if list_name not in globals():
            continue

        for card in globals()[list_name]:
            if card.get("id") == card_id:
                return card

    if "PARTISAN_CARD" in globals():
        if PARTISAN_CARD.get("id") == card_id:
            return PARTISAN_CARD

    return None