# cards.py

from settings import *

CARD_POOL = [
    {
        "id": "japanese_infantry",
        "name": "일본군 보병",
        "icon": "🪖",
        "cost": 1,
        "unit_type": TYPE_INFANTRY,
        "count": 6,
        "hp": 342,
        "damage": {
            TYPE_INFANTRY: 75,
            TYPE_VEHICLE: 42,
            TYPE_TANK: 11,
            TYPE_BUILDING: 35,
        },
        "bayonet_damage": {
            TYPE_INFANTRY: 200,
            TYPE_VEHICLE: 23,
            TYPE_TANK: 3,
            TYPE_BUILDING: 42,
        },
        "attack_delay": 1500,
        "bayonet_attack_delay": 1200,
        "attack_range": 80,
        "bayonet_range": 20,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "is_ranged_infantry": True,
        "abilities": ["반자이 돌격"],
    },

    {
        "id": "suicide_soldier",
        "name": "자폭병",
        "icon": "폭",
        "cost": 3,
        "unit_type": TYPE_INFANTRY,
        "count": 1,
        "hp": 704,
        "damage": {
            TYPE_INFANTRY: 896,
            TYPE_VEHICLE: 960,
            TYPE_TANK: 1026,
            TYPE_BUILDING: 680,
        },
        "attack_delay": 800,
        "attack_range": 20,
        "splash_radius": 90,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "abilities": ["야마토 정신", "돌격", "자폭"],
    },

    {
        "id": "night_raiders",
        "name": "야습대",
        "icon": "단",
        "cost": 4,
        "unit_type": TYPE_INFANTRY,
        "count": 4,
        "hp": 574,
        "damage": {
            TYPE_INFANTRY: 34,
            TYPE_VEHICLE: 23,
            TYPE_TANK: 7,
            TYPE_BUILDING: 20,
        },
        "attack_delay": 400,
        "attack_range": 60,
        "preferred_range": 40,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": True,
        "is_ranged_infantry": True,
        "abilities": ["위장", "매복"],
    },

    {
        "id": "lunge_mine_soldier",
        "name": "자돌 폭뢰병",
        "icon": "뢰",
        "cost": 2,
        "unit_type": TYPE_INFANTRY,
        "count": 3,
        "hp": 460,
        "damage": {
            TYPE_INFANTRY: 460,
            TYPE_VEHICLE: 950,
            TYPE_TANK: 840,
            TYPE_BUILDING: 530,
        },
        "attack_delay": 500,
        "attack_range": 20,
        "splash_radius": 40,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "target_priority": [TYPE_TANK, TYPE_VEHICLE, TYPE_BUILDING, TYPE_INFANTRY],
        "abilities": ["자폭", "돌격", "대전차병"],
    },

    {
        "id": "officer",
        "name": "장교",
        "icon": "칼",
        "cost": 3,
        "unit_type": TYPE_INFANTRY,
        "count": 1,
        "hp": 1630,
        "damage": {
            TYPE_INFANTRY: 520,
            TYPE_VEHICLE: 0,
            TYPE_TANK: 0,
            TYPE_BUILDING: 500,
        },
        "attack_delay": 1200,
        "attack_range": 20,
        "splash_radius": 0,
        "speed": SPEED_SLOW,
        "can_flank": False,
        "target_priority": [TYPE_INFANTRY, TYPE_BUILDING],
        "abilities": ["돌격", "근접 전환", "돌격 부여"],
    },
    
    {
        "id": "bicycle_infantry",
        "name": "자전거 보병",
        "icon": "자",
        "cost": 5,
        "unit_type": TYPE_INFANTRY,
        "count": 3,
        "hp": 803,
        "damage": {
            TYPE_INFANTRY: 45,
            TYPE_VEHICLE: 25,
            TYPE_TANK: 13,
            TYPE_BUILDING: 35,
        },
        "grenade_damage": {
            TYPE_INFANTRY: 450,
            TYPE_VEHICLE: 340,
            TYPE_TANK: 150,
            TYPE_BUILDING: 375,
        },
        "attack_delay": 500,
        "attack_range": 60,
        "preferred_range": 40,
        "splash_radius": 0,
        "grenade_delay": 10000,
        "grenade_range": 60,
        "grenade_splash_radius": 45,
        "speed": SPEED_SLOW,
        "bicycle_speed": SPEED_FAST,
        "can_flank": False,
        "is_ranged_infantry": True,
        "abilities": ["자전거", "수류탄"],
    },
    
    {
        "id": "AMBUSH_SQUAD_CARD",
        "name": "매복대",
        "cost": 3,

        "hp": 423,

        "weapon": "소총",

        "damage": {
            TYPE_INFANTRY: 112,
            TYPE_VEHICLE: 73,
            TYPE_TANK: 6,
            TYPE_BUILDING: 82,
        },

        "attack_delay": 1500,
        "attack_range": 80,

        "splash_radius": 0,

        "speed": SPEED_SLOW,

        "count": 4,

        "icon": "🪖",

        "abilities": [
            "매복",
            "반자이 돌격",
        ],

        # 중앙 건물 전용 배치
        "center_spawn_only": True,

        # 반자이 총검
        "bayonet_damage": {
            TYPE_INFANTRY: 200,
            TYPE_VEHICLE: 23,
            TYPE_TANK: 3,
            TYPE_BUILDING: 42,
        },
        "bayonet_attack_delay": 1200,
        "bayonet_range": 20,
}
]